#include "WaveformItem.h"

#include "core/Resample.h"
#include "core/SampleRing.h"
#include "model/StreamController.h"

#include <QSGFlatColorMaterial>
#include <QSGGeometryNode>
#include <QSGNode>
#include <QTimer>

#include <algorithm>
#include <cmath>

namespace {

// Refresh cadence. The scene graph coalesces update() calls, so this is an
// upper bound on repaints rather than a guarantee of them.
constexpr int kFrameIntervalMs = 16; // ~60 fps

// Never let autoscale amplify pure noise into a full-height trace.
constexpr double kMinRangeUv = 5.0;

// Above this many samples in the window, raw mode falls back to min/max. One
// vertex per sample is cheap at the rates this board runs (10 s at 1000 SPS is
// 10k vertices per channel), but the cap keeps a pathological ring size from
// allocating without bound.
constexpr std::size_t kRawSampleCap = 65536;

// Fraction of the full lane height an AUTOSCALED trace may fill, leaving
// headroom so a peak does not touch the lane edge. Calibrated and manual
// scales deliberately have no such factor - a stated mm/mV must be exact.
constexpr double kLaneFill = 0.45;

} // namespace

WaveformItem::WaveformItem(QQuickItem *parent) : QQuickItem(parent)
{
    setFlag(ItemHasContents, true);

    auto *timer = new QTimer(this);
    timer->setInterval(kFrameIntervalMs);
    connect(timer, &QTimer::timeout, this, [this] {
        if (!m_running || !isVisible()) {
            return;
        }
        // While the display is frozen the source data is static, so a full-rate
        // repaint is wasted work - but repainting occasionally is what keeps the
        // frozen frame robust. Stopping entirely leaves the item permanently
        // clean, and the next thing that invalidates the scene graph (a resize,
        // a re-expose, a grabWindow()) renders it blank with nothing to restore
        // it.
        if (m_controller && m_controller->isPaused() && (++m_pausedTick % 12) != 0) {
            return;
        }
        update();
    });
    timer->start();
}

WaveformItem::~WaveformItem() = default;

void WaveformItem::setController(StreamController *c)
{
    if (m_controller == c) {
        return;
    }
    m_controller = c;
    emit controllerChanged();
    update();
}

void WaveformItem::setAutoScale(bool on)
{
    if (m_autoScale == on) {
        return;
    }
    m_autoScale = on;
    emit autoScaleChanged();
    update();
}

void WaveformItem::setRangeMicrovolts(double uv)
{
    uv = qBound(1.0, uv, 500000.0);
    if (qFuzzyCompare(m_range, uv)) {
        return;
    }
    m_range = uv;
    emit rangeMicrovoltsChanged();
    update();
}

void WaveformItem::setGridColor(const QColor &c)
{
    if (m_gridColor == c) {
        return;
    }
    m_gridColor = c;
    emit gridColorChanged();
    update();
}

void WaveformItem::setInterpolate(bool on)
{
    if (m_interpolate == on) {
        return;
    }
    m_interpolate = on;
    emit interpolateChanged();
    update();
}

void WaveformItem::setRemoveDc(bool on)
{
    if (m_removeDc == on) {
        return;
    }
    m_removeDc = on;
    emit removeDcChanged();
    update();
}

void WaveformItem::setRaw(bool on)
{
    if (m_raw == on) {
        return;
    }
    m_raw = on;
    emit rawChanged();
    update();
}

void WaveformItem::setRunning(bool running)
{
    if (m_running == running) {
        return;
    }
    m_running = running;
    emit runningChanged();
    update();
}

void WaveformItem::rebuild(int columns)
{
    // displayRing() is the filtered stream when filtering is on. Filtering
    // happens upstream in the IO thread so the IIR state stays continuous.
    emg::SampleRing *ring = m_controller ? m_controller->displayRing() : nullptr;
    if (!ring) {
        m_traces.clear();
        return;
    }

    const int channels = ring->channels();
    const int rate = m_controller->sampleRate() > 0 ? m_controller->sampleRate() : 1000;
    const auto want =
        static_cast<std::size_t>(m_controller->windowSeconds() * rate);

    m_traces.resize(static_cast<std::size_t>(channels));
    m_window.resize(std::max<std::size_t>(want, 1));

    for (int ch = 0; ch < channels; ++ch) {
        Trace &t = m_traces[static_cast<std::size_t>(ch)];
        t.valid = false;

        const std::size_t have = ring->readLatest(ch, m_window.data(), want);
        if (have == 0) {
            continue;
        }

        // Never stretch. If the ring holds less than the window asks for -
        // still filling at startup, or a window wider than capacity - the
        // trace occupies only the matching fraction of the width, anchored to
        // the right where the newest sample is. Stretching would silently
        // change the effective mm/s and put the trace out of step with the
        // grid, which is the one thing a calibrated time base may not do.
        const double fillFrac =
            want > 0 ? std::min(1.0, double(have) / double(want)) : 1.0;
        t.cols = std::max(1, int(std::llround(double(columns) * fillFrac)));
        t.x0 = columns - t.cols;

        // Display-only DC removal. Raw gain-6 traces sit on a large offset and
        // are unviewable untreated; this never touches recorded data, and real
        // filtering is deferred (ARCHITECTURE.md section 8).
        //
        // Note what this is, though: the mean is taken over the *display
        // window*, and the window scrolls. That makes it a high-pass with a
        // corner near 1/windowSeconds - about 0.2 Hz at the default 5 s. It is
        // mild, but it is not nothing, and it is the one piece of processing
        // that used to be unavoidable even with the band-pass switched off. So
        // it is switchable now: `removeDc == false` draws absolute microvolts,
        // which is what you want when the question is "what did the ADC
        // actually see" - a railed input reads hundreds of millivolts, and
        // centring it would hide exactly that.
        double sum = 0.0;
        for (std::size_t i = 0; i < have; ++i) {
            sum += m_window[i];
        }
        t.mean = sum / double(have);

        // What actually gets subtracted before drawing. t.mean stays the true
        // window mean either way, because the RMS readout is an AC figure and
        // is meant to be taken about the mean regardless of how it is drawn.
        const double offset = (m_removeDc && !m_raw) ? t.mean : 0.0;

        double sq = 0.0;
        double peak = 0.0;
        double lo = m_window[0];
        double hi = m_window[0];
        for (std::size_t i = 0; i < have; ++i) {
            const double ac = m_window[i] - t.mean;
            sq += ac * ac;
            // Peak drives autoscale, so it must measure what is drawn: with DC
            // removal off, an offset trace would otherwise be scaled as if it
            // were centred and run straight off the lane.
            peak = std::max(peak, std::abs(m_window[i] - offset));
            lo = std::min<double>(lo, m_window[i]);
            hi = std::max<double>(hi, m_window[i]);
        }
        t.p2p = hi - lo;
        t.rms = std::sqrt(sq / double(have));
        t.peak = peak;
        t.last = m_window[have - 1] - offset;

        // Raw: hand the samples straight to the geometry builder. No DC
        // removal (offset is already 0 above), no reconstruction, no envelope.
        //
        // Plotting more samples than pixel columns is deliberate here. The
        // polyline simply overlaps itself, which is what a bench scope does and
        // is the honest rendering - unlike the min/max path below, which
        // collapses each column to a max-to-min bar. That distinction is not
        // academic: a 100 Hz sine at 1000 SPS in a 5 s window puts about five
        // samples, half a cycle, in every column, so min/max draws a
        // full-amplitude bar at every x and the sine renders as a solid block.
        t.rawMode = m_raw && have <= kRawSampleCap;
        if (t.rawMode) {
            t.samples.assign(m_window.begin(),
                             m_window.begin() + static_cast<std::ptrdiff_t>(have));
            t.mins.clear();
            t.maxs.clear();
            t.interpolated = false;
            t.valid = true;
            continue;
        }

        t.mins.assign(static_cast<std::size_t>(t.cols), 0.0f);
        t.maxs.assign(static_cast<std::size_t>(t.cols), 0.0f);

        // Remove DC once, up front, so both branches below work on the centred
        // signal and the interpolator is not asked to reconstruct a large offset.
        m_centred.resize(have);
        for (std::size_t i = 0; i < have; ++i) {
            m_centred[i] = static_cast<float>(m_window[i] - offset);
        }

        if (m_interpolate && !m_raw && have < static_cast<std::size_t>(t.cols)) {
            // Zoomed in: fewer samples than pixel columns. Sample-and-hold here
            // draws a visible staircase, and straight chords between samples
            // undershoot every peak. Band-limited (Whittaker-Shannon)
            // reconstruction draws the unique continuous curve the samples
            // imply - see core/Resample.h.
            t.resampled.resize(static_cast<std::size_t>(t.cols));
            emg::lanczosResample(m_centred.data(), have, t.resampled.data(),
                            static_cast<std::size_t>(t.cols));

            for (int x = 0; x < t.cols; ++x) {
                t.mins[x] = t.resampled[static_cast<std::size_t>(x)];
                t.maxs[x] = t.mins[x];
            }
            t.interpolated = true;
        } else {
            // Zoomed out: more samples than columns. Min/max per column, never
            // stride-sampling - stride would drop exactly the motor-unit spikes
            // EMG is about, and interpolating here would alias.
            for (int x = 0; x < t.cols; ++x) {
                const auto lo = static_cast<std::size_t>(
                    double(x) * double(have) / double(t.cols));
                auto hi = static_cast<std::size_t>(
                    double(x + 1) * double(have) / double(t.cols));
                hi = std::min(hi, have);

                if (lo >= hi) {
                    const float v = m_centred[std::min(lo, have - 1)];
                    t.mins[x] = v;
                    t.maxs[x] = v;
                    continue;
                }

                float mn = std::numeric_limits<float>::max();
                float mx = std::numeric_limits<float>::lowest();
                for (std::size_t i = lo; i < hi; ++i) {
                    const float v = m_centred[i];
                    mn = std::min(mn, v);
                    mx = std::max(mx, v);
                }
                t.mins[x] = mn;
                t.maxs[x] = mx;
            }
            t.interpolated = false;
        }

        t.valid = true;
    }

    // Push readouts to the channel strips.
    if (auto *channelModel = m_controller->channels()) {
        for (int ch = 0; ch < channels && ch < channelModel->rowCount(); ++ch) {
            const Trace &t = m_traces[static_cast<std::size_t>(ch)];
            // Envelope comes from the DSP chain's sliding 250 ms RMS, not from
            // the display window: a window-wide RMS averages a brief
            // contraction away, which is exactly the symptom that prompted it.
            channelModel->updateReadout(ch, t.valid ? t.last : 0.0,
                                        m_controller->envelope(ch),
                                        m_controller->heartRate(ch),
                                        t.valid ? t.p2p : 0.0);
        }
    }
}

QSGNode *WaveformItem::updatePaintNode(QSGNode *old, UpdatePaintNodeData *)
{
    const int w = int(width());
    const int h = int(height());

    if (w <= 1 || h <= 1 || !m_controller) {
        delete old;
        return nullptr;
    }

    rebuild(w);

    auto *root = static_cast<QSGNode *>(old);
    if (!root) {
        root = new QSGNode;
    }

    emg::SampleRing *ring = m_controller->ring();
    const int channels = ring ? ring->channels() : 0;
    ChannelModel *model = m_controller->channels();

    // Build the list of channels we will actually draw, so hidden channels do
    // not leave gaps in the lane layout.
    std::vector<int> lanes;
    for (int ch = 0; ch < channels; ++ch) {
        if (!model || model->isVisible(ch)) {
            lanes.push_back(ch);
        }
    }

    const int wanted = static_cast<int>(lanes.size());

    // Reconcile child node count with the number of visible channels.
    while (root->childCount() > wanted) {
        QSGNode *n = root->lastChild();
        root->removeChildNode(n);
        delete n;
    }
    while (root->childCount() < wanted) {
        auto *node = new QSGGeometryNode;
        auto *geometry = new QSGGeometry(QSGGeometry::defaultAttributes_Point2D(), 0);
        geometry->setDrawingMode(QSGGeometry::DrawLineStrip);
        geometry->setLineWidth(1.0f);
        node->setGeometry(geometry);
        node->setFlag(QSGNode::OwnsGeometry, true);

        auto *material = new QSGFlatColorMaterial;
        node->setMaterial(material);
        node->setFlag(QSGNode::OwnsMaterial, true);

        root->appendChildNode(node);
    }

    if (wanted == 0) {
        return root;
    }

    const double laneHeight = double(h) / wanted;

    for (int lane = 0; lane < wanted; ++lane) {
        const int ch = lanes[static_cast<std::size_t>(lane)];
        auto *node = static_cast<QSGGeometryNode *>(root->childAtIndex(lane));
        auto *geometry = node->geometry();

        QColor colour(0x4F, 0xC3, 0xF7);
        if (model) {
            const QVariant v = model->data(model->index(ch, 0), ChannelModel::ColorRole);
            if (v.canConvert<QColor>()) {
                colour = v.value<QColor>();
            }
        }
        static_cast<QSGFlatColorMaterial *>(node->material())->setColor(colour);

        const Trace &t = (ch < int(m_traces.size())) ? m_traces[std::size_t(ch)] : Trace{};
        if (!t.valid || (t.mins.empty() && !t.rawMode)) {
            geometry->allocate(0);
            node->markDirty(QSGNode::DirtyGeometry);
            continue;
        }

        // Pixels per microvolt.
        //
        // Autoscale tracks the window peak with a floor, so a quiet channel
        // does not turn its own noise into a full-height trace, and keeps
        // kLaneFill of headroom so a peak never touches the lane edge.
        //
        // Calibrated and manual map m_range to exactly a half-lane: no fill
        // factor and no halving, because m_range is already a half-range
        // (QML sends microvolts per half-lane, and the manual box is labelled
        // in +/- units). A stated mm/mV has to be measurable against the grid,
        // so clipping is preferable to an unstated gain.
        const double centre = (lane + 0.5) * laneHeight;
        const double pxPerUv =
            m_autoScale
                ? (laneHeight * kLaneFill) / std::max(t.peak, kMinRangeUv)
                : (laneHeight * 0.5) / m_range;

        if (t.rawMode) {
            // One vertex per sample, spread across the columns this trace
            // occupies. Nothing is dropped, nothing is invented.
            const std::size_t n = t.samples.size();
            geometry->allocate(int(n));
            QSGGeometry::Point2D *v = geometry->vertexDataAsPoint2D();

            const double xStep =
                n > 1 ? double(t.cols - 1) / double(n - 1) : 0.0;
            for (std::size_t i = 0; i < n; ++i) {
                const double y = centre - double(t.samples[i]) * pxPerUv;
                v[i].set(float(double(t.x0) + double(i) * xStep),
                         float(qBound(0.0, y, double(h))));
            }
        } else if (t.interpolated) {
            // One vertex per column: a genuine curve through the reconstructed
            // waveform. Emitting the min/max pair here would just duplicate
            // every point and halve the effective vertex budget.
            geometry->allocate(t.cols);
            QSGGeometry::Point2D *v = geometry->vertexDataAsPoint2D();

            for (int x = 0; x < t.cols; ++x) {
                const double y = centre - t.mins[std::size_t(x)] * pxPerUv;
                v[x].set(float(t.x0 + x), float(qBound(0.0, y, double(h))));
            }
        } else {
            geometry->allocate(t.cols * 2);
            QSGGeometry::Point2D *v = geometry->vertexDataAsPoint2D();

            for (int x = 0; x < t.cols; ++x) {
                const double yMax = centre - t.maxs[std::size_t(x)] * pxPerUv;
                const double yMin = centre - t.mins[std::size_t(x)] * pxPerUv;

                // Two vertices per column: the line strip walks down one column
                // and across to the next, drawing the envelope as a solid band.
                v[x * 2 + 0].set(float(t.x0 + x),
                                 float(qBound(0.0, yMax, double(h))));
                v[x * 2 + 1].set(float(t.x0 + x),
                                 float(qBound(0.0, yMin, double(h))));
            }
        }

        node->markDirty(QSGNode::DirtyGeometry);
    }

    return root;
}
