#include "SpectrumItem.h"

#include "core/SampleRing.h"
#include "model/StreamController.h"

#include <QSGFlatColorMaterial>
#include <QSGGeometryNode>
#include <QSGNode>
#include <QTimer>

#include <algorithm>
#include <cmath>

namespace {

// Spectra need far less refresh than a scrolling trace: the Welch average is
// over seconds of data, so recomputing at 60 Hz would burn four transforms per
// frame to redraw a nearly identical picture. 10 Hz looks live and costs ~6x
// less.
constexpr int kRefreshMs = 100;

// Headroom above the peak when autoscaling, in dB.
constexpr double kAutoHeadroomDb = 10.0;
constexpr double kAutoSpanDb = 70.0;

} // namespace

SpectrumItem::SpectrumItem(QQuickItem *parent) : QQuickItem(parent)
{
    setFlag(ItemHasContents, true);

    auto *timer = new QTimer(this);
    timer->setInterval(kRefreshMs);
    connect(timer, &QTimer::timeout, this, [this] {
        if (!m_running || !isVisible()) {
            return;
        }
        // While the display is frozen the source data is static, so a full-rate
        // repaint is wasted work - but repainting occasionally is what keeps the
        // frozen frame robust. Stopping entirely leaves the item permanently
        // clean, and the next thing that invalidates the scene graph (a resize,
        // a re-expose, a grabWindow()) renders it blank with nothing to restore
        // it.
        if (m_controller && m_controller->isPaused() && (++m_pausedTick % 12) != 0) {
            return;
        }
        update();
    });
    timer->start();
}

SpectrumItem::~SpectrumItem() = default;

void SpectrumItem::setController(StreamController *c)
{
    if (m_controller == c) {
        return;
    }
    m_controller = c;
    emit controllerChanged();
    update();
}

void SpectrumItem::setRunning(bool running)
{
    if (m_running == running) {
        return;
    }
    m_running = running;
    emit runningChanged();
    update();
}

void SpectrumItem::setMaxFrequencyHz(double hz)
{
    hz = qBound(10.0, hz, 20000.0);
    if (qFuzzyCompare(m_maxFreq, hz)) {
        return;
    }
    m_maxFreq = hz;
    emit maxFrequencyHzChanged();
    update();
}

void SpectrumItem::setFloorDb(double db)
{
    if (qFuzzyCompare(m_floorDb, db)) {
        return;
    }
    m_floorDb = db;
    emit floorDbChanged();
    update();
}

void SpectrumItem::setCeilingDb(double db)
{
    if (qFuzzyCompare(m_ceilingDb, db)) {
        return;
    }
    m_ceilingDb = db;
    emit ceilingDbChanged();
    update();
}

void SpectrumItem::setAutoScale(bool on)
{
    if (m_autoScale == on) {
        return;
    }
    m_autoScale = on;
    emit autoScaleChanged();
    update();
}

void SpectrumItem::rebuild()
{
    // Deliberately the RAW ring, never the filtered one: a spectrum with the
    // notch already applied hides the mains spike you opened this view to find,
    // and a band-passed spectrum cannot show you drift either.
    emg::SampleRing *ring = m_controller ? m_controller->spectrumRing() : nullptr;
    if (!ring) {
        m_spectra.clear();
        return;
    }

    const int channels = ring->channels();
    const double rate = m_controller->sampleRate() > 0 ? m_controller->sampleRate() : 1000;

    // Analyse the same span the time view shows, so the two agree about what
    // "now" means - but never less than a second, or the Welch average has too
    // few segments to settle.
    const double seconds = std::max(1.0, m_controller->windowSeconds());
    const auto want = static_cast<std::size_t>(seconds * rate);

    m_spectra.resize(static_cast<std::size_t>(channels));
    m_window.resize(std::max<std::size_t>(want, 1));

    for (int ch = 0; ch < channels; ++ch) {
        emg::SpectrumResult &s = m_spectra[static_cast<std::size_t>(ch)];
        const std::size_t have = ring->readLatest(ch, m_window.data(), want);

        if (have == 0) {
            s.valid = false;
            continue;
        }
        // Analyse over the band the signal actually occupies, which the
        // controller already knows from the signal-mode preset. Using the
        // fixed EMG band for an ECG measures only the noise above it.
        emg::computeSpectrum(m_window.data(), have, rate, 0, s,
                             m_controller->highpassHz(),
                             m_controller->lowpassHz());
    }

    // Median frequency is the reason to look at this view at all, so push it to
    // the channel strips.
    if (auto *model = m_controller->channels()) {
        for (int ch = 0; ch < channels && ch < model->rowCount(); ++ch) {
            const emg::SpectrumResult &s = m_spectra[static_cast<std::size_t>(ch)];
            model->updateSpectrumReadout(ch, s.valid ? s.medianFrequencyHz : 0.0,
                                         s.valid ? s.peakFrequencyHz : 0.0);
        }
    }
}

QSGNode *SpectrumItem::updatePaintNode(QSGNode *old, UpdatePaintNodeData *)
{
    const int w = int(width());
    const int h = int(height());

    if (w <= 1 || h <= 1 || !m_controller) {
        delete old;
        return nullptr;
    }

    rebuild();

    auto *root = static_cast<QSGNode *>(old);
    if (!root) {
        root = new QSGNode;
    }

    emg::SampleRing *ring = m_controller->ring();
    const int channels = ring ? ring->channels() : 0;
    ChannelModel *model = m_controller->channels();

    std::vector<int> lanes;
    for (int ch = 0; ch < channels; ++ch) {
        if (!model || model->isVisible(ch)) {
            lanes.push_back(ch);
        }
    }
    const int wanted = static_cast<int>(lanes.size());

    while (root->childCount() > wanted) {
        QSGNode *n = root->lastChild();
        root->removeChildNode(n);
        delete n;
    }
    while (root->childCount() < wanted) {
        auto *node = new QSGGeometryNode;
        auto *geometry = new QSGGeometry(QSGGeometry::defaultAttributes_Point2D(), 0);
        geometry->setDrawingMode(QSGGeometry::DrawLineStrip);
        geometry->setLineWidth(1.0f);
        node->setGeometry(geometry);
        node->setFlag(QSGNode::OwnsGeometry, true);
        node->setMaterial(new QSGFlatColorMaterial);
        node->setFlag(QSGNode::OwnsMaterial, true);
        root->appendChildNode(node);
    }

    if (wanted == 0) {
        return root;
    }

    // A shared dB scale across lanes when autoscaling, so channel amplitudes
    // stay visually comparable - a per-lane scale would make a quiet channel
    // look as strong as an active one.
    double ceilingDb = m_ceilingDb;
    double floorDb = m_floorDb;

    if (m_autoScale) {
        double peak = -1e9;
        for (int ch : lanes) {
            const auto &s = m_spectra[static_cast<std::size_t>(ch)];
            if (!s.valid) {
                continue;
            }
            const auto maxBin = static_cast<std::size_t>(
                std::min<double>(m_maxFreq / s.binHz, double(s.magnitudeDb.size() - 1)));
            for (std::size_t k = 1; k <= maxBin; ++k) {
                peak = std::max(peak, double(s.magnitudeDb[k]));
            }
        }
        if (peak > -1e8) {
            ceilingDb = std::ceil((peak + kAutoHeadroomDb) / 10.0) * 10.0;
            floorDb = ceilingDb - kAutoSpanDb;
        }
    }

    const double span = std::max(1.0, ceilingDb - floorDb);
    const double laneHeight = double(h) / wanted;

    for (int lane = 0; lane < wanted; ++lane) {
        const int ch = lanes[static_cast<std::size_t>(lane)];
        auto *node = static_cast<QSGGeometryNode *>(root->childAtIndex(lane));
        auto *geometry = node->geometry();

        QColor colour(0x4F, 0xC3, 0xF7);
        if (model) {
            const QVariant v = model->data(model->index(ch, 0), ChannelModel::ColorRole);
            if (v.canConvert<QColor>()) {
                colour = v.value<QColor>();
            }
        }
        static_cast<QSGFlatColorMaterial *>(node->material())->setColor(colour);

        const auto &s = m_spectra[static_cast<std::size_t>(ch)];
        if (!s.valid || s.magnitudeDb.empty() || s.binHz <= 0.0) {
            geometry->allocate(0);
            node->markDirty(QSGNode::DirtyGeometry);
            continue;
        }

        const double top = lane * laneHeight;
        const double usable = laneHeight * 0.9;
        const double base = top + laneHeight * 0.95;

        geometry->allocate(w);
        QSGGeometry::Point2D *v = geometry->vertexDataAsPoint2D();

        const double maxBinF = double(s.magnitudeDb.size() - 1);

        for (int x = 0; x < w; ++x) {
            // Map pixel column -> frequency -> bin. More bins than columns is
            // the normal case, so take the max over each column's bin range:
            // a narrow mains spike must not vanish between samples of the axis.
            const double f0 = m_maxFreq * double(x) / double(w);
            const double f1 = m_maxFreq * double(x + 1) / double(w);

            auto k0 = static_cast<std::size_t>(std::floor(f0 / s.binHz));
            auto k1 = static_cast<std::size_t>(std::ceil(f1 / s.binHz));
            k0 = std::min<double>(k0, maxBinF);
            k1 = std::min<double>(std::max(k1, k0 + 1), maxBinF);

            float db = s.magnitudeDb[k0];
            for (std::size_t k = k0; k <= k1; ++k) {
                db = std::max(db, s.magnitudeDb[k]);
            }

            const double norm = (double(db) - floorDb) / span;
            const double y = base - qBound(0.0, norm, 1.0) * usable;
            v[x].set(float(x), float(qBound(top, y, top + laneHeight)));
        }

        node->markDirty(QSGNode::DirtyGeometry);
    }

    return root;
}
