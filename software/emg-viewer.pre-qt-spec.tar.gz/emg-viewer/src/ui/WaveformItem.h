#pragma once

// Scrolling multi-channel waveform, drawn through the Qt scene graph.
//
// A QQuickItem producing QSGGeometryNodes rather than a QQuickPaintedItem: a
// painted item rasterises on the CPU into an FBO every frame, while the scene
// graph uploads a vertex array and lets the GPU draw it. With 4 channels
// streaming continuously at 1000 SPS that is the difference between a smooth
// trace and a stuttering one.
//
// Decimation is min/max per pixel column, never stride-sampling. A 5 s window
// is 5000 samples across ~1000 px; stride-sampling would drop precisely the
// motor-unit spikes that EMG is about, while two vertices per column (the
// column's minimum and maximum) preserves the true envelope at the same cost.

#include <QQuickItem>
#include <QtQml/qqmlregistration.h>

#include <vector>

class StreamController;

class WaveformItem : public QQuickItem {
    Q_OBJECT
    QML_ELEMENT

    Q_PROPERTY(StreamController *controller READ controller WRITE setController
                   NOTIFY controllerChanged)
    Q_PROPERTY(bool autoScale READ autoScale WRITE setAutoScale NOTIFY autoScaleChanged)
    Q_PROPERTY(double rangeMicrovolts READ rangeMicrovolts WRITE setRangeMicrovolts
                   NOTIFY rangeMicrovoltsChanged)
    Q_PROPERTY(QColor gridColor READ gridColor WRITE setGridColor NOTIFY gridColorChanged)
    Q_PROPERTY(bool running READ isRunning WRITE setRunning NOTIFY runningChanged)
    Q_PROPERTY(bool interpolate READ interpolate WRITE setInterpolate NOTIFY interpolateChanged)
    // Display-only DC removal. On by default because this front end is
    // DC-coupled and an untreated trace sits somewhere off-screen; off shows
    // absolute microvolts, offset included. Never touches recorded data.
    Q_PROPERTY(bool removeDc READ removeDc WRITE setRemoveDc NOTIFY removeDcChanged)
    // Draw the samples and nothing else: no DC removal, no reconstruction, no
    // min/max envelope. One vertex per sample. Overrides removeDc and
    // interpolate while it is on.
    Q_PROPERTY(bool raw READ raw WRITE setRaw NOTIFY rawChanged)

public:
    explicit WaveformItem(QQuickItem *parent = nullptr);
    ~WaveformItem() override;

    StreamController *controller() const { return m_controller; }
    void setController(StreamController *c);

    bool autoScale() const { return m_autoScale; }
    void setAutoScale(bool on);

    double rangeMicrovolts() const { return m_range; }
    void setRangeMicrovolts(double uv);

    QColor gridColor() const { return m_gridColor; }
    void setGridColor(const QColor &c);

    bool isRunning() const { return m_running; }
    void setRunning(bool running);

    // Band-limited reconstruction when zoomed in far enough that there are more
    // pixel columns than samples. No effect when zoomed out, where min/max
    // decimation is used instead.
    bool interpolate() const { return m_interpolate; }
    void setInterpolate(bool on);

    bool removeDc() const { return m_removeDc; }
    void setRemoveDc(bool on);

    bool raw() const { return m_raw; }
    void setRaw(bool on);

signals:
    void controllerChanged();
    void autoScaleChanged();
    void rangeMicrovoltsChanged();
    void gridColorChanged();
    void runningChanged();
    void interpolateChanged();
    void removeDcChanged();
    void rawChanged();

protected:
    QSGNode *updatePaintNode(QSGNode *old, UpdatePaintNodeData *) override;

private:
    // Per-channel envelope for the current viewport, in item coordinates.
    struct Trace {
        std::vector<float> mins;
        std::vector<float> maxs;
        std::vector<float> resampled;  // used when `interpolated` is true
        bool interpolated = false;

        // Raw mode: the window's samples verbatim, one vertex each.
        std::vector<float> samples;
        bool rawMode = false;
        double mean = 0.0;
        double peak = 0.0;
        double rms = 0.0;
        double p2p = 0.0;   // peak-to-peak over the window, microvolts
        double last = 0.0;

        // Columns this trace actually occupies, and where they start. Less
        // than the full width while the ring is still filling, so the trace is
        // never stretched to fit - see rebuild().
        int cols = 0;
        int x0 = 0;
        bool valid = false;
    };

    void rebuild(int columns);

    StreamController *m_controller = nullptr;

    std::vector<float> m_window;   // scratch for one channel's sample window
    std::vector<float> m_centred;  // m_window with the DC mean removed
    std::vector<Trace> m_traces;
    std::vector<double> m_scale;  // per-channel microvolts-per-half-lane

    bool m_autoScale = true;
    double m_range = 500.0; // microvolts mapping to a half-lane (+/-), autoScale off
    QColor m_gridColor{0x2A, 0x2F, 0x3A};
    bool m_running = false;
    unsigned m_pausedTick = 0;  // divides the repaint rate while frozen
    bool m_interpolate = true;
    bool m_removeDc = true;
    bool m_raw = false;
};
