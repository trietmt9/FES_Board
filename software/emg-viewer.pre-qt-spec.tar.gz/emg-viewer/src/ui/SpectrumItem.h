#pragma once

// Frequency-domain view: one Welch amplitude spectrum per channel, in lanes
// matching the time-domain scope.
//
// Separate from WaveformItem rather than a mode inside it. They share almost
// nothing: different axes (Hz vs seconds, dB vs microvolts), different
// reduction (averaged periodograms vs min/max decimation), different update
// cost. Folding both into one updatePaintNode would be a bigger tangle than the
// small amount of lane-layout code the two now duplicate.

#include <QQuickItem>
#include <QtQml/qqmlregistration.h>

#include "core/Spectrum.h"

#include <vector>

class StreamController;

class SpectrumItem : public QQuickItem {
    Q_OBJECT
    QML_ELEMENT

    Q_PROPERTY(StreamController *controller READ controller WRITE setController
                   NOTIFY controllerChanged)
    Q_PROPERTY(bool running READ isRunning WRITE setRunning NOTIFY runningChanged)
    Q_PROPERTY(double maxFrequencyHz READ maxFrequencyHz WRITE setMaxFrequencyHz
                   NOTIFY maxFrequencyHzChanged)
    Q_PROPERTY(double floorDb READ floorDb WRITE setFloorDb NOTIFY floorDbChanged)
    Q_PROPERTY(double ceilingDb READ ceilingDb WRITE setCeilingDb NOTIFY ceilingDbChanged)
    Q_PROPERTY(bool autoScale READ autoScale WRITE setAutoScale NOTIFY autoScaleChanged)

public:
    explicit SpectrumItem(QQuickItem *parent = nullptr);
    ~SpectrumItem() override;

    StreamController *controller() const { return m_controller; }
    void setController(StreamController *c);

    bool isRunning() const { return m_running; }
    void setRunning(bool running);

    double maxFrequencyHz() const { return m_maxFreq; }
    void setMaxFrequencyHz(double hz);

    double floorDb() const { return m_floorDb; }
    void setFloorDb(double db);

    double ceilingDb() const { return m_ceilingDb; }
    void setCeilingDb(double db);

    bool autoScale() const { return m_autoScale; }
    void setAutoScale(bool on);

signals:
    void controllerChanged();
    void runningChanged();
    void maxFrequencyHzChanged();
    void floorDbChanged();
    void ceilingDbChanged();
    void autoScaleChanged();

protected:
    QSGNode *updatePaintNode(QSGNode *old, UpdatePaintNodeData *) override;

private:
    void rebuild();

    StreamController *m_controller = nullptr;

    std::vector<float> m_window;                  // scratch: one channel's samples
    std::vector<emg::SpectrumResult> m_spectra;   // one per channel

    bool m_running = false;
    unsigned m_pausedTick = 0;  // divides the repaint rate while frozen
    double m_maxFreq = 500.0;   // sEMG has nothing above ~450 Hz
    double m_floorDb = -40.0;
    double m_ceilingDb = 40.0;
    bool m_autoScale = true;
};
