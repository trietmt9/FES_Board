#include <QCommandLineParser>
#include <QPalette>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>
#include <QQuickWindow>
#include <QTimer>

#include "model/StreamController.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QGuiApplication::setApplicationName(QStringLiteral("EMG Viewer"));
    QGuiApplication::setOrganizationName(QStringLiteral("FES_Board"));
    QGuiApplication::setApplicationVersion(QStringLiteral(EMG_VIEWER_VERSION));

    QCommandLineParser parser;
    parser.setApplicationDescription(
        QStringLiteral("Real-time EMG acquisition and visualisation for the FES_Board."));
    parser.addHelpOption();
    parser.addVersionOption();

    const QCommandLineOption replayOpt(
        {QStringLiteral("r"), QStringLiteral("replay")},
        QStringLiteral("Open a recorded .emgraw capture on startup."),
        QStringLiteral("file"));
    const QCommandLineOption portOpt(
        {QStringLiteral("p"), QStringLiteral("port")},
        QStringLiteral("Serial port to connect to on startup, e.g. ttyACM0."),
        QStringLiteral("port"));
    const QCommandLineOption baudOpt(
        {QStringLiteral("b"), QStringLiteral("baud")},
        QStringLiteral("Baud rate (default 921600)."), QStringLiteral("rate"),
        QStringLiteral("921600"));

    // Renders a frame to PNG and exits. Useful for documentation shots and for
    // CI to catch a scene-graph regression that would otherwise need a human
    // looking at the window.
    const QCommandLineOption grabOpt(
        QStringLiteral("grab"),
        QStringLiteral("Save a screenshot after <ms> milliseconds and exit."),
        QStringLiteral("file"));
    const QCommandLineOption grabDelayOpt(
        QStringLiteral("grab-delay"),
        QStringLiteral("Milliseconds to wait before --grab (default 3000)."),
        QStringLiteral("ms"), QStringLiteral("3000"));

    const QCommandLineOption windowOpt(
        QStringLiteral("window"),
        QStringLiteral("Initial time window in seconds, e.g. 0.2."),
        QStringLiteral("seconds"));

    const QCommandLineOption noFilterOpt(
        QStringLiteral("no-filter"),
        QStringLiteral("Start with the EMG band-pass disabled."));

    parser.addOption(noFilterOpt);
    parser.addOption(windowOpt);
    parser.addOption(replayOpt);
    parser.addOption(portOpt);
    parser.addOption(baudOpt);
    parser.addOption(grabOpt);
    parser.addOption(grabDelayOpt);
    parser.process(app);

    // Basic style: the only one that honours custom colours on every platform
    // without a platform theme overriding them.
    QQuickStyle::setStyle(QStringLiteral("Basic"));

    // Basic-style controls draw their own text from the application palette,
    // not from anything QML sets, so without this the checkbox and tab labels
    // render near-black on the dark background and simply vanish. Keep in step
    // with qml/EmgTheme.qml.
    {
        QPalette dark;
        const QColor text(0xE4, 0xE7, 0xEC);
        const QColor dim(0x8B, 0x94, 0xA3);
        const QColor panel(0x1B, 0x1F, 0x26);
        const QColor panelAlt(0x22, 0x27, 0x2F);
        const QColor accent(0x4F, 0xC3, 0xF7);

        dark.setColor(QPalette::Window, panel);
        dark.setColor(QPalette::WindowText, text);
        dark.setColor(QPalette::Base, QColor(0x14, 0x17, 0x1C));
        dark.setColor(QPalette::AlternateBase, panelAlt);
        dark.setColor(QPalette::Text, text);
        dark.setColor(QPalette::Button, panelAlt);
        dark.setColor(QPalette::ButtonText, text);
        dark.setColor(QPalette::Highlight, accent);
        dark.setColor(QPalette::HighlightedText, QColor(0x14, 0x17, 0x1C));
        dark.setColor(QPalette::ToolTipBase, panelAlt);
        dark.setColor(QPalette::ToolTipText, text);
        dark.setColor(QPalette::PlaceholderText, dim);
        dark.setColor(QPalette::Disabled, QPalette::Text, dim);
        dark.setColor(QPalette::Disabled, QPalette::ButtonText, dim);
        dark.setColor(QPalette::Disabled, QPalette::WindowText, dim);

        QGuiApplication::setPalette(dark);
    }

    QQmlApplicationEngine engine;

    QObject::connect(
        &engine, &QQmlApplicationEngine::objectCreationFailed, &app,
        [] { QCoreApplication::exit(-1); }, Qt::QueuedConnection);

    // Qt 6.5 gained loadFromModule(); on the 6.4 baseline we load the module's
    // resource URL directly. The prefix is pinned in CMakeLists.txt.
    engine.load(QUrl(QStringLiteral("qrc:/qt/qml/EmgViewer/Main.qml")));

    if (engine.rootObjects().isEmpty()) {
        return -1;
    }

    // Act on the command line once the UI exists, so status and errors are
    // visible rather than being emitted into a window that is not up yet.
    if (parser.isSet(replayOpt) || parser.isSet(portOpt) || parser.isSet(noFilterOpt)) {
        QTimer::singleShot(0, &app, [&] {
            // Qt 6.5 gained singletonInstance(uri, name); on 6.4 we resolve the
            // type id first.
            const int typeId = qmlTypeId("EmgViewer", 1, 0, "StreamController");
            auto *controller = engine.singletonInstance<StreamController *>(typeId);
            if (!controller) {
                return;
            }

            if (parser.isSet(noFilterOpt)) {
                controller->setFilterEnabled(false);
            }

            if (parser.isSet(windowOpt)) {
                controller->setWindowSeconds(parser.value(windowOpt).toDouble());
            }

            if (parser.isSet(replayOpt)) {
                controller->openReplay(QUrl::fromLocalFile(parser.value(replayOpt)));
            } else {
                controller->setBaudRate(parser.value(baudOpt).toInt());
                controller->setPortName(parser.value(portOpt));
                controller->connectToPort();
            }
        });
    }

    if (parser.isSet(grabOpt)) {
        auto *window = qobject_cast<QQuickWindow *>(engine.rootObjects().first());
        if (!window) {
            qWarning("--grab: root object is not a window");
            return 2;
        }

        const int delay = parser.value(grabDelayOpt).toInt();
        const QString path = parser.value(grabOpt);

        QTimer::singleShot(delay > 0 ? delay : 3000, &app, [window, path] {
            // grabWindow() blocks until the scene graph has produced a frame,
            // so wait for one rather than calling it cold - on a window that
            // has never rendered it simply never returns.
            auto *once = new QMetaObject::Connection;
            *once = QObject::connect(
                window, &QQuickWindow::frameSwapped, window, [window, path, once] {
                    QObject::disconnect(*once);
                    delete once;

                    const QImage image = window->grabWindow();
                    if (image.isNull() || !image.save(path)) {
                        qWarning("--grab: could not save %s", qPrintable(path));
                        QCoreApplication::exit(2);
                        return;
                    }
                    QCoreApplication::quit();
                },
                Qt::QueuedConnection);

            window->update();
        });
    }

    return app.exec();
}
