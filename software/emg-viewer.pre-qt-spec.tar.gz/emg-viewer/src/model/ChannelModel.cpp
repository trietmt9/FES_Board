#include "ChannelModel.h"

#include "core/FrameParser.h"   // DataFrame::channelIndexFor - trace index -> ADS channel

namespace {

// Distinguishable at a glance against a dark scope background, and still
// distinguishable in the common forms of colour blindness.
const QColor kPalette[] = {
    QColor(0x4F, 0xC3, 0xF7), // blue
    QColor(0xFF, 0xB7, 0x4D), // amber
    QColor(0x81, 0xC7, 0x84), // green
    QColor(0xE5, 0x73, 0x73), // red
    QColor(0xBA, 0x68, 0xC8), // purple
    QColor(0x4D, 0xD0, 0xE1), // cyan
    QColor(0xFF, 0x8A, 0x65), // orange
    QColor(0xA1, 0x88, 0x7F), // brown
};
constexpr int kPaletteSize = int(sizeof(kPalette) / sizeof(kPalette[0]));

} // namespace

namespace {

// SBAU171 Table 2. Ten electrodes across eight channels, so a channel's two
// inputs are NOT the two jacks you might expect: LEAD I is channel 2, and
// channels 1 and 4-8 sit against the Wilson Central Terminal.
const char *const kEvmLeads[] = {
    "V6",     // CH1 = V6 - WCT
    "LEAD I", // CH2 = LA - RA
    "LEAD II",// CH3 = LL - RA
    "V2", "V3", "V4", "V5", "V1",
};

// Which physical inputs each EVM channel actually differences.
const char *const kEvmInputs[] = {
    "V6-WCT", "LA-RA", "LL-RA", "V2-WCT", "V3-WCT", "V4-WCT", "V5-WCT", "V1-WCT",
};

} // namespace

ChannelModel::ChannelModel(QObject *parent) : QAbstractListModel(parent)
{
    setChannelCount(4);
}

int ChannelModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : static_cast<int>(m_channels.size());
}

QVariant ChannelModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_channels.size()) {
        return {};
    }
    const Channel &c = m_channels.at(index.row());

    switch (role) {
    case NameRole:
    case Qt::DisplayRole:
        return c.name;
    case ColorRole:
        return c.color;
    case VisibleRole:
        return c.visible;
    case JackRole:
        return c.jack;
    case LastValueRole:
        return c.lastValue;
    case RmsRole:
        return c.rms;
    case MedianHzRole:
        return c.medianHz;
    case PeakHzRole:
        return c.peakHz;
    case BpmRole:
        return c.bpm;
    case P2pRole:
        return c.p2p;
    default:
        return {};
    }
}

bool ChannelModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_channels.size()) {
        return false;
    }
    if (role != VisibleRole) {
        return false;
    }

    Channel &c = m_channels[index.row()];
    const bool v = value.toBool();
    if (c.visible == v) {
        return false;
    }
    c.visible = v;
    emit dataChanged(index, index, {VisibleRole});
    emit visibilityChanged();
    return true;
}

QHash<int, QByteArray> ChannelModel::roleNames() const
{
    // Prefixed rather than plain ("color", "visible", ...) because a delegate's
    // required properties shadow the item's own: a role named "visible" would
    // silently hide every channel strip.
    return {
        {NameRole, "chName"},   {ColorRole, "chColor"},
        {VisibleRole, "chVisible"}, {JackRole, "chJack"},
        {LastValueRole, "chLast"},  {RmsRole, "chRms"},
        {MedianHzRole, "chMedianHz"}, {PeakHzRole, "chPeakHz"},
        {BpmRole, "chBpm"}, {P2pRole, "chP2p"},
    };
}

void ChannelModel::setChannelCount(int count)
{
    count = qBound(1, count, kPaletteSize);
    if (count == m_channels.size()) {
        return;
    }

    beginResetModel();
    m_channels.clear();
    for (int i = 0; i < count; ++i) {
        Channel c;
        c.name = QStringLiteral("CH%1").arg(i + 1);
        c.color = kPalette[i % kPaletteSize];
        c.visible = true;
        m_channels.append(c);
    }
    relabel();
    endResetModel();

    emit countChanged();
}

void ChannelModel::relabel()
{
    const int n = m_channels.size();

    for (int i = 0; i < n; ++i) {
        // Trace i is not necessarily CH(i+1): the firmware may stream a subset,
        // and it says which one in the DATA frame's mask.
        const int ads = emg::DataFrame::channelIndexFor(m_chMask, i, n) % 8;

        if (m_scheme == Scheme::Ads1298Evm) {
            m_channels[i].name = QString::fromLatin1(kEvmLeads[ads]);
            m_channels[i].jack = QString::fromLatin1(kEvmInputs[ads]);
        } else {
            m_channels[i].name = QStringLiteral("CH%1").arg(ads + 1);
            // FES_Board routes four differential pairs to jacks J1-J4. The
            // jack-to-channel order is the schematic's intent and is NOT yet
            // confirmed on hardware - see ARCHITECTURE.md section 9.
            m_channels[i].jack =
                ads < 4 ? QStringLiteral("J%1").arg(ads + 1) : QString();
        }
    }
}

void ChannelModel::setChannelMask(quint8 mask)
{
    if (m_chMask == mask) {
        return;
    }
    m_chMask = mask;

    beginResetModel();
    relabel();
    endResetModel();

    emit schemeChanged();
}

void ChannelModel::setScheme(Scheme s)
{
    if (m_scheme == s) {
        return;
    }
    m_scheme = s;

    beginResetModel();
    relabel();
    endResetModel();

    emit schemeChanged();
}

bool ChannelModel::isVisible(int channel) const
{
    if (channel < 0 || channel >= m_channels.size()) {
        return false;
    }
    return m_channels.at(channel).visible;
}

void ChannelModel::setVisible(int channel, bool visible)
{
    setData(index(channel, 0), visible, VisibleRole);
}

void ChannelModel::updateSpectrumReadout(int channel, double medianHz, double peakHz)
{
    if (channel < 0 || channel >= m_channels.size()) {
        return;
    }
    Channel &c = m_channels[channel];
    c.medianHz = medianHz;
    c.peakHz = peakHz;

    const QModelIndex i = index(channel, 0);
    emit dataChanged(i, i, {MedianHzRole, PeakHzRole});
}

void ChannelModel::updateReadout(int channel, double lastValue, double rms,
                                 double bpm, double p2p)
{
    if (channel < 0 || channel >= m_channels.size()) {
        return;
    }
    Channel &c = m_channels[channel];
    c.lastValue = lastValue;
    c.rms = rms;
    c.bpm = bpm;
    c.p2p = p2p;

    const QModelIndex i = index(channel, 0);
    emit dataChanged(i, i, {LastValueRole, RmsRole, BpmRole, P2pRole});
}
