#pragma once

// Per-channel display state.
//
// Four channels, because the PCB routes exactly four differential pairs
// (/IN1P../IN4N) out to jacks J1-J4. ADS1298 channels 5-8 have no electrode
// inputs and are powered down in firmware, so they never appear here - the
// channel count still comes from the INFO frame rather than being assumed.

#include <QAbstractListModel>
#include <QColor>
#include <QList>
#include <QtQml/qqmlregistration.h>

class ChannelModel : public QAbstractListModel {
    Q_OBJECT
    QML_ELEMENT
    Q_PROPERTY(int count READ rowCount NOTIFY countChanged)

public:
    /// Channel naming depends on which board is attached. Wrong labels on an
    /// instrument are worse than no labels, so this is explicit rather than
    /// assumed.
    enum class Scheme {
        Ads1298Evm,  ///< ADS1298ECG-FE: SBAU171 Table 2 lead assignment
        FesBoard,    ///< FES_Board: four differential pairs on jacks J1-J4
    };
    Q_ENUM(Scheme)

    enum Roles {
        NameRole = Qt::UserRole + 1,
        ColorRole,
        VisibleRole,
        JackRole,      // which TRS jack feeds this channel
        LastValueRole, // most recent sample, microvolts
        RmsRole,       // window RMS, microvolts
        MedianHzRole,  // median frequency, Hz - the sEMG fatigue index
        PeakHzRole,    // strongest bin in the sEMG band, Hz
        BpmRole,       // heart rate, ECG mode only
        P2pRole,       // peak-to-peak over the display window, microvolts
    };

    struct Channel {
        QString name;
        QColor color;
        bool visible = true;
        QString jack;
        double lastValue = 0.0;
        double rms = 0.0;
        double medianHz = 0.0;
        double peakHz = 0.0;
        double bpm = 0.0;
        double p2p = 0.0;
    };

    explicit ChannelModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    bool setData(const QModelIndex &index, const QVariant &value, int role) override;
    QHash<int, QByteArray> roleNames() const override;

    void setChannelCount(int count);
    void setScheme(Scheme s);
    Scheme scheme() const { return m_scheme; }

    /// Which ADS129x channels the streamed traces actually are, from
    /// DataFrame::chMask (bit 0 = CH1). Zero means the legacy contiguous
    /// CH1..CHn. Labels are looked up by ADS channel, not by trace position -
    /// a firmware streaming CH2 and CH3 must show LEAD I and LEAD II, not V6
    /// and LEAD I.
    void setChannelMask(quint8 mask);
    quint8 channelMask() const { return m_chMask; }
    bool isVisible(int channel) const;

    // Called from the GUI thread at render rate; emits dataChanged so the
    // channel strips update without a per-sample signal.
    void updateReadout(int channel, double lastValue, double rms,
                       double bpm = 0.0, double p2p = 0.0);

    // Written by SpectrumItem, which is the only thing that computes them.
    void updateSpectrumReadout(int channel, double medianHz, double peakHz);

public slots:
    void setVisible(int channel, bool visible);

signals:
    void countChanged();
    void schemeChanged();
    void visibilityChanged();

private:
    void relabel();

    Scheme m_scheme = Scheme::Ads1298Evm;
    quint8 m_chMask = 0;
    QList<Channel> m_channels;
};
