#pragma once

// The single object QML talks to. Owns the source, the worker threads, the
// sample ring and the recorder, and republishes everything as properties.
//
// Deliberately the only place that knows about threading: sources and the
// recorder are moved onto worker threads here, and every cross-thread edge is a
// queued signal carrying either a QByteArray or a small struct.

#include "core/EmgFilter.h"
#include "core/FrameParser.h"
#include "core/SampleRing.h"
#include "io/ISampleSource.h"
#include "model/ChannelModel.h"
#include "model/LinkStats.h"
#include "model/LogModel.h"

#include <QObject>
#include <QStringList>
#include <QUrl>
#include <QtQml/qqmlregistration.h>

QT_BEGIN_NAMESPACE
class QThread;
QT_END_NAMESPACE

class ISampleSource;
class SerialSource;
class ReplaySource;
class Recorder;

class StreamController : public QObject {
    Q_OBJECT
    QML_ELEMENT
    QML_SINGLETON

    Q_PROPERTY(QStringList availablePorts READ availablePorts NOTIFY availablePortsChanged)
    Q_PROPERTY(QString portName READ portName WRITE setPortName NOTIFY portNameChanged)
    Q_PROPERTY(int baudRate READ baudRate WRITE setBaudRate NOTIFY baudRateChanged)
    Q_PROPERTY(QList<int> baudRates READ baudRates CONSTANT)

    Q_PROPERTY(bool running READ isRunning NOTIFY runningChanged)
    Q_PROPERTY(Mode mode READ mode NOTIFY modeChanged)
    Q_PROPERTY(QString statusText READ statusText NOTIFY statusTextChanged)

    // Device identity, all sourced from the INFO frame - never hardcoded.
    Q_PROPERTY(int sampleRate READ sampleRate NOTIFY streamInfoChanged)
    Q_PROPERTY(int channelCount READ channelCount NOTIFY streamInfoChanged)
    Q_PROPERTY(int gain READ gain NOTIFY streamInfoChanged)
    Q_PROPERTY(double vrefVolts READ vrefVolts NOTIFY streamInfoChanged)
    Q_PROPERTY(QString chipName READ chipName NOTIFY streamInfoChanged)
    Q_PROPERTY(QString firmwareVersion READ firmwareVersion NOTIFY streamInfoChanged)
    Q_PROPERTY(double uvPerCode READ uvPerCode NOTIFY streamInfoChanged)
    Q_PROPERTY(bool haveInfo READ haveInfo NOTIFY streamInfoChanged)

    Q_PROPERTY(LinkStats stats READ stats NOTIFY statsChanged)
    Q_PROPERTY(ChannelModel *channels READ channels CONSTANT)
    Q_PROPERTY(LogModel *log READ log CONSTANT)

    Q_PROPERTY(bool recording READ isRecording NOTIFY recordingChanged)
    Q_PROPERTY(QString recordingPath READ recordingPath NOTIFY recordingChanged)
    Q_PROPERTY(qint64 recordedBytes READ recordedBytes NOTIFY recordingProgress)
    Q_PROPERTY(qint64 recordedSamples READ recordedSamples NOTIFY recordingProgress)

    Q_PROPERTY(double replayProgress READ replayProgress NOTIFY replayProgressChanged)
    Q_PROPERTY(bool replayPaused READ replayPaused NOTIFY replayPausedChanged)

    Q_PROPERTY(double windowSeconds READ windowSeconds WRITE setWindowSeconds
                   NOTIFY windowSecondsChanged)

    // Clinical display calibration. Sweep speed and gain are the two numbers
    // printed on every ECG strip, because a trace cannot be measured without
    // them: 25 mm/s makes one 5 mm square 0.20 s, which is what lets a rate be
    // counted by eye. They live here rather than in the view because the
    // vitals bar and the scope must agree on them.
    Q_PROPERTY(double sweepMmPerSec READ sweepMmPerSec WRITE setSweepMmPerSec
                   NOTIFY calibrationChanged)
    Q_PROPERTY(double gainMmPerMv READ gainMmPerMv WRITE setGainMmPerMv
                   NOTIFY calibrationChanged)

    // Display freeze. Acquisition, recording and the link statistics all carry
    // on; only the rendering stops.
    Q_PROPERTY(bool paused READ isPaused WRITE setPaused NOTIFY pausedChanged)
    Q_PROPERTY(Display displayMode READ displayMode WRITE setDisplayMode
                   NOTIFY displayModeChanged)

    Q_PROPERTY(int channelScheme READ channelScheme WRITE setChannelScheme
                   NOTIFY channelSchemeChanged)
    Q_PROPERTY(bool filterEnabled READ filterEnabled WRITE setFilterEnabled
                   NOTIFY filterChanged)
    Q_PROPERTY(bool notchEnabled READ notchEnabled WRITE setNotchEnabled
                   NOTIFY filterChanged)
    Q_PROPERTY(int mainsHz READ mainsHz WRITE setMainsHz NOTIFY filterChanged)
    Q_PROPERTY(double envelopeMs READ envelopeMs WRITE setEnvelopeMs NOTIFY filterChanged)
    Q_PROPERTY(SignalMode signalMode READ signalMode WRITE setSignalMode NOTIFY signalModeChanged)
    Q_PROPERTY(bool ecgMode READ isEcgMode NOTIFY signalModeChanged)
    Q_PROPERTY(double highpassHz READ highpassHz NOTIFY filterChanged)
    Q_PROPERTY(double lowpassHz READ lowpassHz NOTIFY filterChanged)
    // True when the ADC's own sinc^3 filter (-3 dB at 0.262*fDR) rolls off
    // inside the sEMG band - i.e. the data rate is too low to see all of it.
    Q_PROPERTY(bool adcFilterLimitsBand READ adcFilterLimitsBand NOTIFY streamInfoChanged)
    Q_PROPERTY(double adcBandwidthHz READ adcBandwidthHz NOTIFY streamInfoChanged)

public:
    enum class Mode { Idle, Live, Replay };
    Q_ENUM(Mode)

    // Which view is on screen. Lives here rather than in the QML because the
    // channel strips need it too, and they are in a different subtree.
    enum class Display { Time, Frequency };
    Q_ENUM(Display)

    /// What is being measured. Selects the filter band, and it matters a great
    /// deal: the EMG preset's 20 Hz high-pass sits on top of the QRS complex and
    /// removes the P wave, the ST segment and most of the T wave outright.
    enum class SignalMode {
        Emg,            ///< 20-450 Hz, SENIAM surface EMG
        EcgMonitor,     ///< 0.5-40 Hz, bedside monitoring - rejects drift hard
        EcgDiagnostic,  ///< 0.05-150 Hz, diagnostic ECG per IEC 60601-2-25
    };
    Q_ENUM(SignalMode)

    explicit StreamController(QObject *parent = nullptr);
    ~StreamController() override;

    QStringList availablePorts() const { return m_ports; }
    QString portName() const { return m_portName; }
    void setPortName(const QString &name);
    int baudRate() const { return m_baudRate; }
    void setBaudRate(int baud);
    QList<int> baudRates() const;

    bool isRunning() const { return m_running; }
    Mode mode() const { return m_mode; }
    QString statusText() const { return m_status; }

    int sampleRate() const { return m_sampleRate; }
    int channelCount() const { return m_channelCount; }
    int gain() const { return m_gain; }
    double vrefVolts() const { return m_vrefUv / 1e6; }
    QString chipName() const;
    QString firmwareVersion() const { return m_fwVersion; }
    double uvPerCode() const;
    bool haveInfo() const { return m_haveInfo; }

    LinkStats stats() const { return m_stats; }
    ChannelModel *channels() { return &m_channels; }
    LogModel *log() { return &m_log; }

    bool isRecording() const { return m_recording; }
    QString recordingPath() const { return m_recordingPath; }
    qint64 recordedBytes() const { return m_recordedBytes; }
    qint64 recordedSamples() const { return m_recordedSamples; }

    double replayProgress() const { return m_replayProgress; }
    bool replayPaused() const { return m_replayPaused; }

    double windowSeconds() const { return m_windowSeconds; }

    double sweepMmPerSec() const { return m_sweepMmPerSec; }
    void setSweepMmPerSec(double v)
    {
        if (v <= 0.0 || qFuzzyCompare(m_sweepMmPerSec, v)) {
            return;
        }
        m_sweepMmPerSec = v;
        emit calibrationChanged();
    }

    double gainMmPerMv() const { return m_gainMmPerMv; }
    void setGainMmPerMv(double v)
    {
        if (v <= 0.0 || qFuzzyCompare(m_gainMmPerMv, v)) {
            return;
        }
        m_gainMmPerMv = v;
        emit calibrationChanged();
    }
    void setWindowSeconds(double s);

    Display displayMode() const { return m_displayMode; }
    void setDisplayMode(Display d);

    int channelScheme() const { return int(m_channels.scheme()); }
    void setChannelScheme(int s);

    bool filterEnabled() const { return m_filter.enabled; }
    void setFilterEnabled(bool on);
    bool notchEnabled() const { return m_filter.notchEnabled; }
    void setNotchEnabled(bool on);
    int mainsHz() const { return int(m_filter.notchHz); }
    void setMainsHz(int hz);
    double envelopeMs() const { return m_filter.envelopeMs; }
    void setEnvelopeMs(double ms);

    SignalMode signalMode() const { return m_signalMode; }
    void setSignalMode(SignalMode m);
    bool isEcgMode() const { return m_signalMode != SignalMode::Emg; }

    /// Heart rate for @p channel in BPM, 0 when no QRS is discernible.
    Q_INVOKABLE double heartRate(int channel) const;
    double highpassHz() const { return m_filter.highpassHz; }
    double lowpassHz() const { return m_filter.lowpassHz; }

    double adcBandwidthHz() const { return 0.262 * m_sampleRate; }
    bool adcFilterLimitsBand() const { return adcBandwidthHz() < m_filter.lowpassHz; }

    // For the render items, on the GUI thread. Never null.
    //
    // Two rings: the waveform shows the filtered stream when filtering is on,
    // while the spectrum always reads raw - a spectrum with the notch already
    // applied hides the very mains spike you opened it to find.
    /// Live raw ring - the sources' write target. Never frozen.
    emg::SampleRing *ring() { return &m_ring; }
    emg::SampleRing *filteredRing() { return &m_filteredRing; }

    /// What the waveform reads: filtered or raw, live or frozen.
    emg::SampleRing *displayRing()
    {
        if (m_paused) {
            return m_filter.enabled ? &m_frozenFiltered : &m_frozenRaw;
        }
        return m_filter.enabled ? &m_filteredRing : &m_ring;
    }

    /// What the spectrum reads: always raw, but frozen when paused.
    emg::SampleRing *spectrumRing() { return m_paused ? &m_frozenRaw : &m_ring; }

    bool isPaused() const { return m_paused; }
    void setPaused(bool paused);
    Q_INVOKABLE void togglePause() { setPaused(!m_paused); }

    /// Per-channel RMS envelope of the filtered signal, in microvolts.
    double envelope(int channel) const;

public slots:
    void refreshPorts();
    void connectToPort();
    void disconnectFromPort();

    void openReplay(const QUrl &fileUrl);
    void replayPlayPause();
    void replayRestart();
    void setReplaySpeed(double multiplier);

    void startRecording(const QUrl &folderUrl, bool raw, bool csv);
    void stopRecording();

    void clearLog();

signals:
    void availablePortsChanged();
    void portNameChanged();
    void baudRateChanged();
    void runningChanged();
    void modeChanged();
    void statusTextChanged();
    void streamInfoChanged();
    void statsChanged();
    void recordingChanged();
    void recordingProgress();
    void replayProgressChanged();
    void replayPausedChanged();
    void windowSecondsChanged();
    void calibrationChanged();
    void displayModeChanged();
    void filterChanged();
    void signalModeChanged();
    void pausedChanged();
    void channelSchemeChanged();
    void errorMessage(const QString &message);

private slots:
    void onInfo(const emg::InfoFrame &info);
    void onStats(const emg::ParserStats &stats, quint64 overflows,
                 quint64 lostSamples);
    void onChannelMap(quint8 mask);
    void onSourceError(const QString &message);
    void onSourceStopped();

private:
    void teardownSource();
    void setStatus(const QString &text);
    void setMode(Mode m);
    void setRunning(bool running);
    void reconfigureRing();
    void pushFilterConfig();

    // Filter choices survive a restart. Without this every launch reverts to
    // the factory band, which is how a session ends up staring at an ECG
    // through a 20 Hz high-pass and calling the result noise.
    void loadSettings();
    void saveSettings() const;

    emg::SampleRing m_ring;          // raw microvolts
    emg::SampleRing m_filteredRing;  // band-passed microvolts
    emg::SampleRing m_frozenRaw;     // snapshots taken when the display freezes
    emg::SampleRing m_frozenFiltered;
    bool m_paused = false;
    ISampleSource::EnvelopeBank m_envelopes{};
    ISampleSource::EnvelopeBank m_heartRates{};
    // ECG monitor, to agree with FilterConfig's default corners and with
    // ChannelModel::Scheme::Ads1298Evm. These three must not drift apart: a
    // Signal selector reading "EMG" while the corners sit at 0.5-40 Hz is
    // worse than either default on its own. Persisted, so this only decides
    // the very first launch - see loadSettings()/saveSettings().
    SignalMode m_signalMode = SignalMode::EcgMonitor;
    emg::FilterConfig m_filter;
    ChannelModel m_channels;
    LogModel m_log;

    QThread *m_ioThread = nullptr;
    QThread *m_recThread = nullptr;
    SerialSource *m_serial = nullptr;
    ReplaySource *m_replay = nullptr;
    Recorder *m_recorder = nullptr;
    ISampleSource *m_active = nullptr;

    QStringList m_ports;
    QString m_portName;
    int m_baudRate = 921600;

    bool m_running = false;
    Mode m_mode = Mode::Idle;
    QString m_status = QStringLiteral("Idle");

    // Defaults mirror the firmware's compiled-in configuration; they are
    // replaced the moment an INFO frame arrives.
    int m_sampleRate = 1000;
    int m_channelCount = 4;
    int m_gain = 6;
    double m_vrefUv = 2400000.0;
    quint8 m_chipId = 0;
    QString m_fwVersion;
    bool m_haveInfo = false;

    LinkStats m_stats;
    emg::ParserStats m_lastParser;
    qint64 m_lastStatsMs = 0;

    bool m_recording = false;
    QString m_recordingPath;
    qint64 m_recordedBytes = 0;
    qint64 m_recordedSamples = 0;

    double m_replayProgress = 0.0;
    bool m_replayPaused = false;

    double m_windowSeconds = 5.0;
    // Clinical defaults: 25 mm/s and 10 mm/mV are the standard settings every
    // ECG is read at, and the ones a reader's eye is calibrated to.
    double m_sweepMmPerSec = 25.0;
    double m_gainMmPerMv = 10.0;
    Display m_displayMode = Display::Time;
};
