#include "StreamController.h"

#include "io/Recorder.h"
#include "io/ReplaySource.h"
#include "io/SerialSource.h"

#include <QDateTime>
#include <QDir>
#include <QSerialPortInfo>
#include <QSettings>
#include <QThread>
#include <QUrl>

#include <cstdlib>   // std::abs

namespace {
// Ten seconds of history at the highest rate we expect to see. Deep enough that
// the GUI thread would have to stall for ten seconds to observe a torn window.
// Seconds of history each ring holds. This is also the ceiling on
// windowSeconds (see setWindowSeconds), and the window is derived from the
// sweep speed and the plot width - so a ring that is too short silently
// truncates the window and the trace ends up drawn at a different mm/s
// than the grid. 40 s covers the slowest sweep (12.5 mm/s) across a plot
// nearly 500 mm wide, which is wider than any real display.
constexpr double kRingSeconds = 40.0;
} // namespace

StreamController::StreamController(QObject *parent) : QObject(parent)
{
    qRegisterMetaType<emg::InfoFrame>("emg::InfoFrame");
    qRegisterMetaType<emg::ParserStats>("emg::ParserStats");
    qRegisterMetaType<emg::FilterConfig>("emg::FilterConfig");

    loadSettings();
    reconfigureRing();
    refreshPorts();

    m_ioThread = new QThread(this);
    m_ioThread->setObjectName(QStringLiteral("emg-io"));
    m_ioThread->start();

    m_recThread = new QThread(this);
    m_recThread->setObjectName(QStringLiteral("emg-rec"));
    m_recThread->start();

    m_recorder = new Recorder;
    m_recorder->moveToThread(m_recThread);

    connect(m_recThread, &QThread::finished, m_recorder, &QObject::deleteLater);
    connect(m_recorder, &Recorder::errorOccurred, this,
            [this](const QString &m) { emit errorMessage(m); });
    connect(m_recorder, &Recorder::progress, this,
            [this](qint64 bytes, qint64 samples) {
                m_recordedBytes = bytes;
                m_recordedSamples = samples;
                emit recordingProgress();
            });
    connect(m_recorder, &Recorder::recordingStarted, this,
            [this](const QString &raw, const QString &csv) {
                m_recording = true;
                m_recordingPath = raw.isEmpty() ? csv : raw;
                emit recordingChanged();
            });
    connect(m_recorder, &Recorder::recordingStopped, this,
            [this](qint64, qint64) {
                m_recording = false;
                emit recordingChanged();
            });
}

StreamController::~StreamController()
{
    saveSettings();
    teardownSource();

    if (m_ioThread) {
        m_ioThread->quit();
        m_ioThread->wait();
    }
    if (m_recThread) {
        m_recThread->quit();
        m_recThread->wait();
    }
}

// ------------------------------------------------------------------ getters

QList<int> StreamController::baudRates() const
{
    // 921600 first: it is what the firmware streams at. The slower rates are
    // only useful for talking to an older build still on the console default.
    return {921600, 460800, 230400, 115200};
}

QString StreamController::chipName() const
{
    // Low 5 bits == 0x12 identifies the 8-channel parts; 0x92 is the ADS1298
    // and 0xD2 the ADS1298R. Same check the firmware makes after ads_read_id().
    switch (m_chipId) {
    case 0x92:
        return QStringLiteral("ADS1298");
    case 0xD2:
        return QStringLiteral("ADS1298R");
    case 0x00:
        return QStringLiteral("unknown");
    default:
        return QStringLiteral("0x%1 (unexpected)")
            .arg(m_chipId, 2, 16, QLatin1Char('0'));
    }
}

double StreamController::uvPerCode() const
{
    if (m_gain == 0) {
        return 0.0;
    }
    return m_vrefUv / m_gain / emg::kFullScaleCode;
}

// ------------------------------------------------------------------ setters

void StreamController::setPortName(const QString &name)
{
    if (m_portName == name) {
        return;
    }
    m_portName = name;
    emit portNameChanged();
}

void StreamController::setBaudRate(int baud)
{
    if (m_baudRate == baud || baud <= 0) {
        return;
    }
    m_baudRate = baud;
    emit baudRateChanged();
}

void StreamController::setWindowSeconds(double s)
{
    // Lower bound well under one screen-width of samples, so the band-limited
    // reconstruction path in WaveformItem is reachable.
    s = qBound(0.05, s, kRingSeconds);
    if (qFuzzyCompare(m_windowSeconds, s)) {
        return;
    }
    m_windowSeconds = s;
    emit windowSecondsChanged();
}

void StreamController::setDisplayMode(Display d)
{
    if (m_displayMode == d) {
        return;
    }
    m_displayMode = d;
    emit displayModeChanged();
}

double StreamController::envelope(int channel) const
{
    if (channel < 0 || channel >= int(emg::kMaxChannels)) {
        return 0.0;
    }
    return m_envelopes[std::size_t(channel)].load(std::memory_order_relaxed);
}

void StreamController::setChannelScheme(int s)
{
    const auto scheme = static_cast<ChannelModel::Scheme>(s);
    if (m_channels.scheme() == scheme) {
        return;
    }
    m_channels.setScheme(scheme);
    emit channelSchemeChanged();
}

double StreamController::heartRate(int channel) const
{
    if (channel < 0 || channel >= int(emg::kMaxChannels)) {
        return 0.0;
    }
    return m_heartRates[std::size_t(channel)].load(std::memory_order_relaxed);
}

void StreamController::setSignalMode(SignalMode m)
{
    if (m_signalMode == m) {
        return;
    }
    m_signalMode = m;

    // Band presets. The high-pass is the consequential one: 20 Hz is right for
    // EMG and destroys an ECG, while 0.05 Hz preserves the ST segment but lets
    // every bit of electrode drift through.
    switch (m) {
    case SignalMode::Emg:
        m_filter.highpassHz = 20.0;
        m_filter.lowpassHz = 450.0;
        break;
    case SignalMode::EcgMonitor:
        m_filter.highpassHz = 0.5;
        m_filter.lowpassHz = 40.0;
        break;
    case SignalMode::EcgDiagnostic:
        m_filter.highpassHz = 0.05;
        m_filter.lowpassHz = 150.0;
        break;
    }

    pushFilterConfig();
    emit signalModeChanged();
    emit filterChanged();
}

void StreamController::setFilterEnabled(bool on)
{
    if (m_filter.enabled == on) {
        return;
    }
    m_filter.enabled = on;
    pushFilterConfig();
    emit filterChanged();
}

void StreamController::setNotchEnabled(bool on)
{
    if (m_filter.notchEnabled == on) {
        return;
    }
    m_filter.notchEnabled = on;
    pushFilterConfig();
    emit filterChanged();
}

void StreamController::setMainsHz(int hz)
{
    if (hz != 50 && hz != 60) {
        return;
    }
    if (int(m_filter.notchHz) == hz) {
        return;
    }
    m_filter.notchHz = hz;
    pushFilterConfig();
    emit filterChanged();
}

void StreamController::setEnvelopeMs(double ms)
{
    ms = qBound(20.0, ms, 1000.0);
    if (qFuzzyCompare(m_filter.envelopeMs, ms)) {
        return;
    }
    m_filter.envelopeMs = ms;
    pushFilterConfig();
    emit filterChanged();
}

void StreamController::loadSettings()
{
    const QSettings st;

    // Read the mode first and let setSignalMode() derive the corners, so the
    // band and the selector can never disagree - even if a stale settings file
    // from an older build carries corner values that no preset produces.
    const int mode = st.value(QStringLiteral("filter/signalMode"),
                              int(m_signalMode)).toInt();
    if (mode >= int(SignalMode::Emg) && mode <= int(SignalMode::EcgDiagnostic)) {
        m_signalMode = static_cast<SignalMode>(mode);
    }
    switch (m_signalMode) {
    case SignalMode::Emg:
        m_filter.highpassHz = 20.0;
        m_filter.lowpassHz = 450.0;
        break;
    case SignalMode::EcgMonitor:
        m_filter.highpassHz = 0.5;
        m_filter.lowpassHz = 40.0;
        break;
    case SignalMode::EcgDiagnostic:
        m_filter.highpassHz = 0.05;
        m_filter.lowpassHz = 150.0;
        break;
    }

    m_filter.enabled =
        st.value(QStringLiteral("filter/enabled"), m_filter.enabled).toBool();
    m_filter.notchEnabled =
        st.value(QStringLiteral("filter/notchEnabled"), m_filter.notchEnabled).toBool();

    const int mains = st.value(QStringLiteral("filter/mainsHz"),
                               int(m_filter.notchHz)).toInt();
    if (mains == 50 || mains == 60) {
        m_filter.notchHz = mains;
    }

    const double env = st.value(QStringLiteral("filter/envelopeMs"),
                                m_filter.envelopeMs).toDouble();
    m_filter.envelopeMs = qBound(20.0, env, 1000.0);

    // No source exists yet, so nothing to push; whichever source is created
    // next picks this up through applyFilterConfig() in setupSource().
}

void StreamController::saveSettings() const
{
    QSettings st;
    st.setValue(QStringLiteral("filter/signalMode"), int(m_signalMode));
    st.setValue(QStringLiteral("filter/enabled"), m_filter.enabled);
    st.setValue(QStringLiteral("filter/notchEnabled"), m_filter.notchEnabled);
    st.setValue(QStringLiteral("filter/mainsHz"), int(m_filter.notchHz));
    st.setValue(QStringLiteral("filter/envelopeMs"), m_filter.envelopeMs);
}

void StreamController::pushFilterConfig()
{
    if (!m_active) {
        return;
    }
    // Queued: the filter state belongs to the source's thread.
    QMetaObject::invokeMethod(m_active, "applyFilterConfig", Qt::QueuedConnection,
                              Q_ARG(emg::FilterConfig, m_filter));
}

void StreamController::setPaused(bool paused)
{
    if (m_paused == paused) {
        return;
    }

    if (paused) {
        // Snapshot before flipping the flag, so the first frozen repaint
        // already has data to draw.
        m_ring.snapshotInto(m_frozenRaw);
        m_filteredRing.snapshotInto(m_frozenFiltered);
    }
    m_paused = paused;

    // In replay the source is ours to stop, and letting it run past a frozen
    // view only throws away capture the user wanted to look at.
    if (m_replay && m_mode == Mode::Replay) {
        QMetaObject::invokeMethod(m_replay, paused ? "pause" : "resume",
                                  Qt::QueuedConnection);
    }

    emit pausedChanged();
}

void StreamController::setStatus(const QString &text)
{
    if (m_status == text) {
        return;
    }
    m_status = text;
    emit statusTextChanged();
}

void StreamController::setMode(Mode m)
{
    if (m_mode == m) {
        return;
    }
    m_mode = m;
    emit modeChanged();
}

void StreamController::setRunning(bool running)
{
    if (m_running == running) {
        return;
    }
    m_running = running;
    emit runningChanged();
}

void StreamController::reconfigureRing()
{
    const auto capacity =
        static_cast<std::size_t>(kRingSeconds * (m_sampleRate > 0 ? m_sampleRate : 1000));
    m_ring.configure(m_channelCount, capacity);
    m_filteredRing.configure(m_channelCount, capacity);
    m_frozenRaw.configure(m_channelCount, capacity);
    m_frozenFiltered.configure(m_channelCount, capacity);
    m_channels.setChannelCount(m_channelCount);
}

// -------------------------------------------------------------------- ports

void StreamController::refreshPorts()
{
    QStringList names;
    const auto ports = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &p : ports) {
        names << p.portName();
    }
    names.sort();

    if (names == m_ports) {
        return;
    }
    m_ports = names;

    // Keep the current selection if it survived; otherwise take the first.
    if (!m_ports.contains(m_portName)) {
        setPortName(m_ports.isEmpty() ? QString() : m_ports.first());
    }
    emit availablePortsChanged();
}

// ------------------------------------------------------------------ sources

void StreamController::teardownSource()
{
    if (!m_active) {
        return;
    }

    // stop() must run on the source's own thread.
    QMetaObject::invokeMethod(m_active, "stop", Qt::BlockingQueuedConnection);
    m_active->disconnect(this);

    ISampleSource *doomed = m_active;
    m_active = nullptr;
    m_serial = nullptr;
    m_replay = nullptr;
    doomed->deleteLater();

    setRunning(false);
    setMode(Mode::Idle);
}

void StreamController::connectToPort()
{
    if (m_running) {
        return;
    }
    setPaused(false);
    if (m_portName.isEmpty()) {
        emit errorMessage(tr("No serial port selected."));
        return;
    }

    teardownSource();
    reconfigureRing();

    m_serial = new SerialSource;
    m_serial->setRing(&m_ring);
    m_serial->setFilteredRing(&m_filteredRing);
    m_serial->setEnvelopes(&m_envelopes);
    m_serial->setHeartRates(&m_heartRates);
    m_serial->applyFilterConfig(m_filter);
    m_serial->setPortName(m_portName);
    m_serial->setBaudRate(m_baudRate);
    m_serial->setForwardRaw(m_recording);
    m_serial->moveToThread(m_ioThread);
    m_active = m_serial;

    connect(m_serial, &ISampleSource::infoReceived, this, &StreamController::onInfo);
    connect(m_serial, &ISampleSource::statsUpdated, this, &StreamController::onStats);
    connect(m_serial, &ISampleSource::channelMapChanged, this,
            &StreamController::onChannelMap);
    connect(m_serial, &ISampleSource::textLine, &m_log, &LogModel::append);
    connect(m_serial, &ISampleSource::errorOccurred, this, &StreamController::onSourceError);
    connect(m_serial, &ISampleSource::stopped, this, &StreamController::onSourceStopped);
    connect(m_serial, &ISampleSource::started, this, [this] {
        setRunning(true);
        setMode(Mode::Live);
        setStatus(tr("Streaming from %1 at %2 baud").arg(m_portName).arg(m_baudRate));
    });
    connect(m_serial, &ISampleSource::rawBytes, m_recorder, &Recorder::write);

    m_haveInfo = false;
    emit streamInfoChanged();

    QMetaObject::invokeMethod(m_serial, "start", Qt::QueuedConnection);
}

void StreamController::disconnectFromPort()
{
    teardownSource();
    setStatus(tr("Idle"));
}

void StreamController::openReplay(const QUrl &fileUrl)
{
    const QString path = fileUrl.isLocalFile() ? fileUrl.toLocalFile() : fileUrl.toString();
    if (path.isEmpty()) {
        return;
    }

    setPaused(false);
    teardownSource();
    reconfigureRing();

    m_replay = new ReplaySource;
    m_replay->setRing(&m_ring);
    m_replay->setFilteredRing(&m_filteredRing);
    m_replay->setEnvelopes(&m_envelopes);
    m_replay->setHeartRates(&m_heartRates);
    m_replay->applyFilterConfig(m_filter);
    m_replay->setFilePath(path);
    m_replay->setForwardRaw(false); // never re-record a replay by accident
    m_replay->moveToThread(m_ioThread);
    m_active = m_replay;

    connect(m_replay, &ISampleSource::infoReceived, this, &StreamController::onInfo);
    connect(m_replay, &ISampleSource::statsUpdated, this, &StreamController::onStats);
    connect(m_replay, &ISampleSource::channelMapChanged, this,
            &StreamController::onChannelMap);
    connect(m_replay, &ISampleSource::textLine, &m_log, &LogModel::append);
    connect(m_replay, &ISampleSource::errorOccurred, this, &StreamController::onSourceError);
    connect(m_replay, &ISampleSource::stopped, this, &StreamController::onSourceStopped);
    connect(m_replay, &ISampleSource::started, this, [this, path] {
        setRunning(true);
        setMode(Mode::Replay);
        setStatus(tr("Replaying %1").arg(QFileInfo(path).fileName()));
    });
    connect(m_replay, &ReplaySource::progressChanged, this, [this](double f) {
        m_replayProgress = f;
        emit replayProgressChanged();
    });
    connect(m_replay, &ReplaySource::pausedChanged, this, [this](bool p) {
        m_replayPaused = p;
        emit replayPausedChanged();
    });

    m_haveInfo = false;
    emit streamInfoChanged();

    QMetaObject::invokeMethod(m_replay, "start", Qt::QueuedConnection);
}

void StreamController::replayPlayPause()
{
    if (!m_replay) {
        return;
    }
    QMetaObject::invokeMethod(m_replay, m_replayPaused ? "resume" : "pause",
                              Qt::QueuedConnection);
}

void StreamController::replayRestart()
{
    if (!m_replay) {
        return;
    }
    QMetaObject::invokeMethod(m_replay, "seekToStart", Qt::QueuedConnection);
}

void StreamController::setReplaySpeed(double multiplier)
{
    if (!m_replay) {
        return;
    }
    QMetaObject::invokeMethod(m_replay, "setSpeed", Qt::QueuedConnection,
                              Q_ARG(double, multiplier));
}

// ---------------------------------------------------------------- recording

void StreamController::startRecording(const QUrl &folderUrl, bool raw, bool csv)
{
    if (m_recording) {
        return;
    }

    QString dir = folderUrl.isLocalFile() ? folderUrl.toLocalFile() : folderUrl.toString();
    if (dir.isEmpty()) {
        dir = QDir::homePath();
    }

    const QString stamp =
        QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss"));
    const QString base = QDir(dir).filePath(QStringLiteral("emg-%1").arg(stamp));

    m_recordedBytes = 0;
    m_recordedSamples = 0;
    emit recordingProgress();

    QMetaObject::invokeMethod(m_recorder, "startRecording", Qt::QueuedConnection,
                              Q_ARG(QString, base), Q_ARG(bool, raw), Q_ARG(bool, csv));

    if (m_serial) {
        m_serial->setForwardRaw(true);
    }
}

void StreamController::stopRecording()
{
    if (m_serial) {
        m_serial->setForwardRaw(false);
    }
    QMetaObject::invokeMethod(m_recorder, "stopRecording", Qt::QueuedConnection);
}

// ------------------------------------------------------------------- events

void StreamController::onInfo(const emg::InfoFrame &info)
{
    if (!info.isValid()) {
        return;
    }

    // Resizing the rings CLEARS them, so this must not fire on small drift:
    // an advertised rate that wanders by a few SPS would wipe the display over
    // and over, which looks exactly like the board resetting.
    //
    // The ring is a capacity in samples, so being 10 % out only changes how many
    // seconds it holds - harmless. A channel-count change genuinely does need a
    // rebuild, because the interleave stride changes.
    const int rateDelta = std::abs(info.sampleRateHz - m_sampleRate);
    const bool rateMovedMaterially =
        m_sampleRate <= 0 || rateDelta * 10 > m_sampleRate;

    const bool rateOrChannelsChanged =
        rateMovedMaterially || info.nChActive != m_channelCount;

    m_sampleRate = info.sampleRateHz;
    m_channelCount = info.nChActive;
    m_gain = info.gain;
    m_vrefUv = info.vrefUv;
    m_chipId = info.chipId;
    m_fwVersion = info.fwVersion;
    m_haveInfo = true;

    // The ring is sized in samples, so a rate or channel-count change has to
    // resize it. This is also why nothing downstream may cache the scale.
    if (rateOrChannelsChanged) {
        reconfigureRing();
    }

    emit streamInfoChanged();
}

void StreamController::onStats(const emg::ParserStats &s, quint64 overflows,
                               quint64 lostSamples)
{
    const qint64 now = QDateTime::currentMSecsSinceEpoch();
    const double dt = m_lastStatsMs > 0 ? (now - m_lastStatsMs) / 1000.0 : 0.0;

    if (dt > 0.0) {
        m_stats.bytesPerSecond = double(s.bytesIn - m_lastParser.bytesIn) / dt;
        m_stats.framesPerSecond = double(s.dataFrames - m_lastParser.dataFrames) / dt;
        m_stats.measuredSps = double(s.samples - m_lastParser.samples) / dt /
                              (m_channelCount > 0 ? m_channelCount : 1);
    }

    m_stats.nominalSps = m_sampleRate;
    m_stats.dataFrames = s.dataFrames;
    m_stats.infoFrames = s.infoFrames;
    m_stats.crcErrors = s.crcErrors;
    m_stats.resyncs = s.resyncs;
    m_stats.droppedFrames = s.droppedFrames;
    m_stats.totalSamples = s.samples;
    m_stats.overflows = overflows;
    // s.samples counts every channel; loss is counted in conversions.
    m_stats.lostSamples = lostSamples;

    m_lastParser = s;
    m_lastStatsMs = now;

    emit statsChanged();
}

void StreamController::onChannelMap(quint8 mask)
{
    m_channels.setChannelMask(mask);
}

void StreamController::onSourceError(const QString &message)
{
    m_log.append(QStringLiteral("<err> %1").arg(message));
    emit errorMessage(message);
    setStatus(message);
}

void StreamController::onSourceStopped()
{
    setRunning(false);
    setMode(Mode::Idle);
}

void StreamController::clearLog()
{
    m_log.clear();
}
