pragma Singleton

import QtQuick

// Dark instrument palette. A scope is looked at for hours in a lab; low
// luminance keeps the traces the brightest thing on screen.
QtObject {
    readonly property color background: "#14171C"
    readonly property color panel: "#1B1F26"
    readonly property color panelAlt: "#22272F"
    readonly property color border: "#2A2F3A"
    readonly property color grid: "#242A33"

    readonly property color text: "#E4E7EC"
    readonly property color textDim: "#8B94A3"
    readonly property color accent: "#4FC3F7"

    readonly property color ok: "#81C784"
    readonly property color warn: "#FFB74D"
    readonly property color error: "#E57373"

    // ECG chart-paper grid. Red-brown so it reads as graph paper without
    // competing with the traces, which stay the brightest thing on screen.
    // Minor = 1 mm, major = 5 mm; at the standard 25 mm/s one major square is
    // 0.20 s and five of them are 1.00 s, which is what makes rate countable
    // by eye (300 / number of major squares between R peaks).
    readonly property color ecgGridMinor: "#33222A"
    readonly property color ecgGridMajor: "#5A3038"

    // Vital-sign readouts: monitor green, high contrast, glanceable.
    readonly property color vital: "#4ADE80"
    readonly property color vitalDim: "#2A6B45"

    readonly property int pad: 10
    readonly property int radius: 6
    readonly property int monoSize: 12
}
