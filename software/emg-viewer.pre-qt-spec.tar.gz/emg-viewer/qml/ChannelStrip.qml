import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import EmgViewer

Rectangle {
    id: strip

    property int channelIndex: 0
    property string channelName: "CH?"
    property color channelColor: EmgTheme.accent
    property bool channelVisible: true
    property string jackName: ""
    property double lastMicrovolts: 0
    property double rmsMicrovolts: 0
    property double medianHz: 0
    property double peakHz: 0
    property double bpm: 0
    property double p2p: 0

    readonly property bool ecgMode: StreamController.ecgMode

    readonly property bool frequencyMode:
        StreamController.displayMode === StreamController.Frequency

    implicitHeight: layout.implicitHeight + 2 * EmgTheme.pad
    color: EmgTheme.panel

    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width
        height: 1
        color: EmgTheme.border
    }

    // Colour key down the left edge, dimmed when the channel is hidden.
    Rectangle {
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 1
        width: 3
        color: strip.channelColor
        opacity: strip.channelVisible ? 1.0 : 0.25
    }

    // Anchored top/left/right but NOT filled: the strip's implicitHeight is
    // derived from this layout, so anchors.fill would make the layout's height
    // depend on its own implicit height and spin the binding evaluator.
    ColumnLayout {
        id: layout

        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: EmgTheme.pad
        anchors.leftMargin: EmgTheme.pad + 4
        spacing: 4

        RowLayout {
            Layout.fillWidth: true
            spacing: 6

            CheckBox {
                checked: strip.channelVisible
                onToggled: StreamController.channels.setVisible(strip.channelIndex, checked)
            }

            Label {
                text: strip.channelName
                color: strip.channelColor
                font.bold: true
                font.pixelSize: 14
            }

            Label {
                // Jack mapping is the schematic's intent and is not yet
                // confirmed on hardware — see ARCHITECTURE.md section 9.
                visible: strip.jackName !== ""
                text: strip.jackName
                color: EmgTheme.textDim
                font.pixelSize: EmgTheme.monoSize
            }

            Item { Layout.fillWidth: true }
        }

        GridLayout {
            Layout.fillWidth: true
            columns: 2
            columnSpacing: 8
            rowSpacing: 2

            Label {
                text: strip.frequencyMode ? qsTr("median")
                    : strip.ecgMode ? qsTr("rate") : qsTr("last")
                color: EmgTheme.textDim
                font.pixelSize: EmgTheme.monoSize
            }
            Label {
                // Median frequency is the surface-EMG fatigue index: it falls
                // as a muscle tires, which is why it earns the top slot here.
                text: {
                    if (strip.frequencyMode)
                        return strip.medianHz > 0 ? strip.medianHz.toFixed(0) + " Hz" : "—"
                    if (strip.ecgMode)
                        return strip.bpm > 0 ? strip.bpm.toFixed(0) + " BPM" : "—"
                    return strip.lastMicrovolts.toFixed(1) + " µV"
                }
                color: EmgTheme.text
                font.family: "monospace"
                font.pixelSize: EmgTheme.monoSize
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignRight
            }

            Label {
                text: strip.frequencyMode ? qsTr("peak")
                    : strip.ecgMode ? qsTr("p-p") : qsTr("envelope")
                color: EmgTheme.textDim
                font.pixelSize: EmgTheme.monoSize
            }
            Label {
                text: {
                    if (strip.frequencyMode)
                        return strip.peakHz > 0 ? strip.peakHz.toFixed(0) + " Hz" : "—"
                    // Peak-to-peak in mV: the number to compare against a
                    // simulator's calibration setting. ECG is quoted in mV by
                    // convention, and 1 mV is the standard R-wave amplitude.
                    if (strip.ecgMode)
                        return (strip.p2p / 1000.0).toFixed(2) + " mV"
                    return strip.rmsMicrovolts.toFixed(1) + " µV"
                }
                color: EmgTheme.text
                font.family: "monospace"
                font.pixelSize: EmgTheme.monoSize
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignRight
            }
        }

        // Coarse activity bar. RMS is DC-removed over the display window, so
        // this tracks muscle activity rather than electrode offset.
        Rectangle {
            Layout.fillWidth: true
            height: 3
            color: EmgTheme.border
            radius: 1.5

            Rectangle {
                width: parent.width * Math.min(1.0, strip.rmsMicrovolts / 200.0)
                height: parent.height
                radius: parent.radius
                color: strip.channelColor

                Behavior on width {
                    NumberAnimation { duration: 80 }
                }
            }
        }
    }
}
