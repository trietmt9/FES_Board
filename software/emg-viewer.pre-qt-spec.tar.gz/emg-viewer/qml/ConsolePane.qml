import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import EmgViewer

// Zephyr console output, which reaches us for free: the frame magic 0xAA 0x55
// is non-ASCII, so log text can never be mistaken for a frame and the parser
// simply passes it through (ARCHITECTURE.md 4.2).
Rectangle {
    id: pane

    color: EmgTheme.panel

    Rectangle {
        anchors.top: parent.top
        width: parent.width
        height: 1
        color: EmgTheme.border
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        RowLayout {
            Layout.fillWidth: true
            Layout.margins: 6
            spacing: 8

            Label {
                text: qsTr("Console")
                color: EmgTheme.text
                font.bold: true
            }

            Label {
                text: qsTr("%1 lines").arg(StreamController.log.count)
                color: EmgTheme.textDim
                font.pixelSize: EmgTheme.monoSize
            }

            Item { Layout.fillWidth: true }

            EmgCheckBox {
                id: followBox
                text: qsTr("Follow")
                checked: true
            }

            Button {
                text: qsTr("Clear")
                onClicked: StreamController.clearLog()
            }
        }

        ListView {
            id: list

            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            model: StreamController.log
            spacing: 0

            ScrollBar.vertical: ScrollBar {}

            delegate: Label {
                required property string line
                required property string severity

                width: list.width
                leftPadding: 8
                rightPadding: 8
                text: line
                font.family: "monospace"
                font.pixelSize: EmgTheme.monoSize
                wrapMode: Text.NoWrap
                elide: Text.ElideRight

                color: severity === "err" ? EmgTheme.error
                     : severity === "wrn" ? EmgTheme.warn
                     : severity === "dbg" ? EmgTheme.textDim
                     : EmgTheme.text
            }

            onCountChanged: {
                if (followBox.checked) {
                    positionViewAtEnd()
                }
            }
        }
    }
}
