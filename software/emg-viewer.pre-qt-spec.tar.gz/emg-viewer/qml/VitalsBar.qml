import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import EmgViewer

// Patient-monitor style vitals strip.
//
// The heart rate is the number a clinician looks for first, so it gets the
// largest type on screen rather than a cell in a table of statistics. It is
// refreshed on a slow timer, not bound to the stream: a rate that flickers
// several times a second is unreadable, and real monitors settle at about 1 Hz.
Rectangle {
    id: root

    implicitHeight: 68
    color: EmgTheme.panel

    // Which lead the rate is derived from. Defaults to index 1, which is
    // LEAD II on the current channel mask - the conventional rhythm lead,
    // because its axis is closest to the heart's own and gives the tallest,
    // most reliably detectable R wave.
    property int rhythmLead: Math.min(1, Math.max(0, StreamController.channels.count - 1))

    property real bpm: 0
    property bool bpmValid: bpm > 20 && bpm < 300

    function refresh() {
        root.bpm = StreamController.running
                 ? StreamController.heartRate(root.rhythmLead)
                 : 0
    }

    Timer {
        interval: 1000
        running: StreamController.running
        repeat: true
        onTriggered: root.refresh()
    }

    Connections {
        target: StreamController
        function onRunningChanged() { root.refresh() }
    }

    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width
        height: 1
        color: EmgTheme.border
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: EmgTheme.pad * 2
        anchors.rightMargin: EmgTheme.pad * 2
        spacing: EmgTheme.pad * 2

        // ---- Heart rate, the headline number -------------------------------
        ColumnLayout {
            spacing: 0

            Label {
                text: qsTr("HR")
                color: EmgTheme.vitalDim
                font.pixelSize: 12
                font.bold: true
            }

            RowLayout {
                spacing: 6

                Label {
                    // Em-dash rather than 0 when there is no rate: a displayed
                    // zero reads as a measured bradycardia, which is exactly
                    // the wrong thing for a medical readout to imply.
                    text: root.bpmValid ? Math.round(root.bpm) : "— —"
                    color: root.bpmValid ? EmgTheme.vital : EmgTheme.vitalDim
                    font.pixelSize: 42
                    font.bold: true
                    font.family: "monospace"
                }

                Label {
                    text: qsTr("bpm")
                    color: EmgTheme.vitalDim
                    font.pixelSize: 13
                    Layout.alignment: Qt.AlignBottom
                    bottomPadding: 8
                }
            }
        }

        // Rhythm-lead selector.
        ColumnLayout {
            spacing: 2

            Label {
                text: qsTr("Rhythm lead")
                color: EmgTheme.textDim
                font.pixelSize: 11
            }

            ComboBox {
                id: leadBox
                Layout.preferredWidth: 150
                Layout.preferredHeight: 28
                model: StreamController.channels
                textRole: "chName"
                currentIndex: root.rhythmLead
                onActivated: {
                    root.rhythmLead = currentIndex
                    root.refresh()
                }
            }
        }

        Rectangle { width: 1; Layout.fillHeight: true; Layout.topMargin: 12
                    Layout.bottomMargin: 12; color: EmgTheme.border }

        // ---- Calibration, the way a printout states it ----------------------
        //
        // Every clinical ECG carries its sweep speed and gain on the strip,
        // because a trace cannot be measured without them. Same reason here.
        ColumnLayout {
            spacing: 2

            Label {
                text: qsTr("Calibration")
                color: EmgTheme.textDim
                font.pixelSize: 11
            }

            Label {
                text: StreamController.sweepMmPerSec + " mm/s   ·   "
                      + StreamController.gainMmPerMv + " mm/mV"
                color: EmgTheme.text
                font.pixelSize: 14
                font.family: "monospace"
            }
        }

        Rectangle { width: 1; Layout.fillHeight: true; Layout.topMargin: 12
                    Layout.bottomMargin: 12; color: EmgTheme.border }

        ColumnLayout {
            spacing: 2

            Label {
                text: qsTr("Signal")
                color: EmgTheme.textDim
                font.pixelSize: 11
            }

            Label {
                text: StreamController.ecgMode ? qsTr("ECG") : qsTr("EMG")
                color: StreamController.ecgMode ? EmgTheme.vital : EmgTheme.accent
                font.pixelSize: 14
                font.bold: true
            }
        }

        Item { Layout.fillWidth: true }

        // Frozen display is a safety point on a medical readout: a paused
        // trace and a disconnected patient look identical otherwise.
        Rectangle {
            visible: StreamController.paused
            Layout.preferredWidth: 96
            Layout.preferredHeight: 30
            radius: EmgTheme.radius
            color: EmgTheme.warn

            Label {
                anchors.centerIn: parent
                text: qsTr("FROZEN")
                color: "#1A1A1A"
                font.bold: true
                font.pixelSize: 13
            }
        }
    }
}
