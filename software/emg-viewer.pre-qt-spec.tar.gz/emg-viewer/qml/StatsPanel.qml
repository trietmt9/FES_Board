import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import EmgViewer

// Link health. Given the DRDY/START problems already met on this hardware, this
// is the first place to look when a capture goes wrong: a measured rate below
// nominal means the firmware is not keeping up with DRDY, CRC errors mean the
// wire is marginal, and seq gaps mean loss upstream of the host.
Rectangle {
    id: panel

    implicitHeight: layout.implicitHeight + 2 * EmgTheme.pad
    color: EmgTheme.panel

    component StatRow: RowLayout {
        id: row

        property string label: ""
        property string value: ""
        property color valueColor: EmgTheme.text

        Layout.fillWidth: true
        spacing: 8

        Label {
            text: row.label
            color: EmgTheme.textDim
            font.pixelSize: EmgTheme.monoSize
        }
        Item { Layout.fillWidth: true }
        Label {
            text: row.value
            color: row.valueColor
            font.family: "monospace"
            font.pixelSize: EmgTheme.monoSize
        }
    }

    // Top/left/right only, not filled - see the note in ChannelStrip.qml: the
    // panel's implicitHeight comes from this layout, so filling would be a
    // binding loop.
    ColumnLayout {
        id: layout

        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: EmgTheme.pad
        spacing: 5

        Label {
            text: qsTr("Device")
            color: EmgTheme.text
            font.bold: true
        }

        StatRow {
            label: qsTr("chip")
            value: StreamController.haveInfo ? StreamController.chipName : "—"
            valueColor: StreamController.haveInfo ? EmgTheme.text : EmgTheme.textDim
        }

        StatRow {
            label: qsTr("channels")
            value: StreamController.haveInfo ? StreamController.channelCount : "—"
        }

        StatRow {
            label: qsTr("sample rate")
            // Straight from the INFO frame, never assumed - the firmware and its
            // docs have disagreed about acquisition constants before.
            value: StreamController.haveInfo
                   ? StreamController.sampleRate + " SPS" : "—"
        }

        StatRow {
            label: qsTr("gain / VREF")
            value: StreamController.haveInfo
                   ? StreamController.gain + "× / " + StreamController.vrefVolts.toFixed(1) + " V"
                   : "—"
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            color: EmgTheme.border
        }

        RowLayout {
            Layout.fillWidth: true

            Label {
                text: qsTr("Link")
                color: EmgTheme.text
                font.bold: true
            }
            Item { Layout.fillWidth: true }
            Rectangle {
                width: 8
                height: 8
                radius: 4
                // Layout.alignment, not anchors: this item is managed by the
                // RowLayout, and anchoring inside a layout is undefined.
                Layout.alignment: Qt.AlignVCenter
                color: !StreamController.running ? EmgTheme.textDim
                     : StreamController.stats.healthy ? EmgTheme.ok
                     : EmgTheme.error
            }
        }

        StatRow {
            label: qsTr("throughput")
            value: (StreamController.stats.bytesPerSecond / 1024).toFixed(1) + " kB/s"
        }

        StatRow {
            label: qsTr("frames")
            value: StreamController.stats.framesPerSecond.toFixed(1) + " /s"
        }

        StatRow {
            label: qsTr("rate")
            value: StreamController.stats.measuredSps.toFixed(0) + " / "
                   + StreamController.stats.nominalSps + " SPS"
            // More than 2% off nominal means samples are being lost somewhere.
            valueColor: {
                const s = StreamController.stats
                if (!StreamController.running || s.nominalSps === 0)
                    return EmgTheme.text
                const err = Math.abs(s.measuredSps - s.nominalSps) / s.nominalSps
                return err > 0.02 ? EmgTheme.warn : EmgTheme.ok
            }
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            color: EmgTheme.border
        }

        StatRow {
            label: qsTr("CRC errors")
            value: StreamController.stats.crcErrors
            valueColor: StreamController.stats.crcErrors > 0 ? EmgTheme.error : EmgTheme.text
        }

        StatRow {
            label: qsTr("dropped frames")
            value: StreamController.stats.droppedFrames
            valueColor: StreamController.stats.droppedFrames > 0 ? EmgTheme.error : EmgTheme.text
        }

        StatRow {
            label: qsTr("fw overflows")
            value: StreamController.stats.overflows
            valueColor: StreamController.stats.overflows > 0 ? EmgTheme.warn : EmgTheme.text
        }

        // Conversions the firmware never delivered, measured against the
        // device's own t_ms. Distinct from "dropped frames", which is loss on
        // the wire - this is loss in the DRDY/SPI path, upstream of it. It is
        // the row to read when a trace looks noisy but everything above is
        // clean: lost conversions leave no gap, they compress time.
        StatRow {
            label: qsTr("lost samples")
            value: StreamController.stats.lostSamples
                   + " (" + StreamController.stats.lostPercent.toFixed(2) + "%)"
            valueColor: {
                const p = StreamController.stats.lostPercent
                if (p >= 1.0)
                    return EmgTheme.error
                return p >= 0.1 ? EmgTheme.warn : EmgTheme.text
            }
        }

        StatRow {
            label: qsTr("resyncs")
            value: StreamController.stats.resyncs
            valueColor: StreamController.stats.resyncs > 0 ? EmgTheme.warn : EmgTheme.text
        }

        StatRow {
            label: qsTr("samples")
            value: StreamController.stats.totalSamples
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            color: EmgTheme.border
            visible: StreamController.recording
        }

        StatRow {
            visible: StreamController.recording
            label: qsTr("recorded")
            value: (StreamController.recordedBytes / 1048576).toFixed(2) + " MB"
            valueColor: EmgTheme.error
        }

        StatRow {
            visible: StreamController.haveInfo
            label: qsTr("firmware")
            value: StreamController.firmwareVersion || qsTr("unknown")
        }

        StatRow {
            visible: StreamController.haveInfo
            label: qsTr("µV / LSB")
            value: StreamController.uvPerCode.toFixed(5)
        }
    }
}
