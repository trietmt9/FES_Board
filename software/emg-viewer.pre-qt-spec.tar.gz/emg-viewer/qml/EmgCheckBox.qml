import QtQuick
import QtQuick.Controls

// CheckBox with a readable label on the dark background.
//
// The Basic style draws its label through an internal CheckLabel that resolves
// its colour from the control palette, and that lookup does not pick up the
// application palette set in main.cpp - so the stock control renders near-black
// text that simply disappears here. Overriding contentItem is the reliable fix.
CheckBox {
    id: control

    contentItem: Label {
        text: control.text
        color: control.enabled ? EmgTheme.text : EmgTheme.textDim
        verticalAlignment: Text.AlignVCenter
        leftPadding: control.indicator.width + control.spacing
    }
}
