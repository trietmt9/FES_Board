import QtQuick
import QtQuick.Window

// Millimetre-calibrated ECG chart paper.
//
// Real graph paper, not decoration: the squares are sized from the display's
// actual pixel density, so at the standard 25 mm/s sweep one major (5 mm)
// square is exactly 0.20 s and one minor (1 mm) square is 0.04 s. That is what
// makes rate readable by eye without waiting for a computed number -
// count major squares between two R peaks and divide into 300.
//
// It is also what fixes a trace that is "too fast to read": an uncalibrated
// window scaled to the widget can put ten seconds in a hand's width, where a
// human cannot separate beats. A fixed mm/s sweep cannot.
Canvas {
    id: root

    // Pixels per millimetre, from the actual screen. Overridable so a display
    // that reports the wrong density can be corrected without touching code.
    property real pxPerMm: Screen.pixelDensity
    property int lanes: 1
    property color minorColor: EmgTheme.ecgGridMinor
    property color majorColor: EmgTheme.ecgGridMajor
    property color laneColor: EmgTheme.border

    onPxPerMmChanged: requestPaint()
    onLanesChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        const ctx = getContext("2d")
        ctx.reset()

        const mm = pxPerMm
        if (mm <= 0 || width <= 0 || height <= 0)
            return

        // Minor 1 mm grid. Skipped below ~3 px/mm, where the lines would merge
        // into a solid wash and hide the trace instead of measuring it.
        if (mm >= 3) {
            ctx.strokeStyle = minorColor
            ctx.lineWidth = 1
            ctx.beginPath()
            for (let x = 0; x < width; x += mm) {
                const px = Math.round(x) + 0.5
                ctx.moveTo(px, 0); ctx.lineTo(px, height)
            }
            for (let y = 0; y < height; y += mm) {
                const py = Math.round(y) + 0.5
                ctx.moveTo(0, py); ctx.lineTo(width, py)
            }
            ctx.stroke()
        }

        // Major 5 mm grid - the one you actually count.
        const big = mm * 5
        ctx.strokeStyle = majorColor
        ctx.lineWidth = 1
        ctx.beginPath()
        for (let x = 0; x < width; x += big) {
            const px = Math.round(x) + 0.5
            ctx.moveTo(px, 0); ctx.lineTo(px, height)
        }
        for (let y = 0; y < height; y += big) {
            const py = Math.round(y) + 0.5
            ctx.moveTo(0, py); ctx.lineTo(width, py)
        }
        ctx.stroke()

        // Lane separators, drawn last so channel boundaries stay unambiguous
        // over the graph paper.
        const n = Math.max(1, lanes)
        ctx.strokeStyle = laneColor
        ctx.lineWidth = 1
        ctx.beginPath()
        for (let i = 0; i <= n; ++i) {
            const y = Math.round(i * height / n) + 0.5
            ctx.moveTo(0, y); ctx.lineTo(width, y)
        }
        ctx.stroke()
    }
}
