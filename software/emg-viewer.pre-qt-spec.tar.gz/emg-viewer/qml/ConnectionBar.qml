import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import QtQuick.Layouts
import EmgViewer

Rectangle {
    id: bar

    implicitHeight: 52
    color: EmgTheme.panel

    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width
        height: 1
        color: EmgTheme.border
    }

    Component.onCompleted: StreamController.refreshPorts()

    // The board enumerates and disappears as it is plugged, reset or reflashed.
    Timer {
        interval: 2000
        running: !StreamController.running
        repeat: true
        onTriggered: StreamController.refreshPorts()
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: EmgTheme.pad
        anchors.rightMargin: EmgTheme.pad
        spacing: EmgTheme.pad

        Label {
            text: qsTr("Port")
            color: EmgTheme.textDim
        }

        ComboBox {
            id: portBox

            Layout.preferredWidth: 150
            enabled: !StreamController.running
            model: StreamController.availablePorts
            currentIndex: Math.max(0, model.indexOf(StreamController.portName))
            onActivated: StreamController.portName = currentValue

            displayText: model.length === 0 ? qsTr("no ports") : currentText
        }

        Label {
            text: qsTr("Baud")
            color: EmgTheme.textDim
        }

        ComboBox {
            Layout.preferredWidth: 110
            enabled: !StreamController.running
            model: StreamController.baudRates
            currentIndex: Math.max(0, model.indexOf(StreamController.baudRate))
            onActivated: StreamController.baudRate = currentValue
        }

        Button {
            text: StreamController.running ? qsTr("Disconnect") : qsTr("Connect")
            enabled: StreamController.running || StreamController.availablePorts.length > 0
            onClicked: StreamController.running ? StreamController.disconnectFromPort()
                                                : StreamController.connectToPort()
        }

        ToolSeparator {}

        Label {
            text: qsTr("Board")
            color: EmgTheme.textDim
        }

        ComboBox {
            // Channel names differ per board: on the ADS1298ECG-FE the ten
            // electrodes are distributed across eight channels (SBAU171
            // Table 2), so CH2 is LEAD I = LA−RA and CH1 is V6−WCT with
            // nothing attached. Mislabelling those is actively misleading.
            Layout.preferredWidth: 150
            model: [qsTr("ADS1298 EVM"), qsTr("FES_Board")]
            currentIndex: StreamController.channelScheme
            onActivated: StreamController.channelScheme = currentIndex
        }

        ToolSeparator {}

        Button {
            text: qsTr("Open capture…")
            enabled: !StreamController.running
            onClicked: openDialog.open()
        }

        Button {
            text: StreamController.recording ? qsTr("Stop recording") : qsTr("Record…")
            enabled: StreamController.running || StreamController.recording
            onClicked: StreamController.recording ? StreamController.stopRecording()
                                                  : folderDialog.open()

            // A recording in progress should be impossible to miss.
            Rectangle {
                visible: StreamController.recording
                anchors.verticalCenter: parent.verticalCenter
                anchors.right: parent.right
                anchors.rightMargin: 6
                // Anchored to the Button (its own parent), which is not layout
                // managed - only the Button itself is.
                width: 8
                height: 8
                radius: 4
                color: EmgTheme.error

                SequentialAnimation on opacity {
                    running: StreamController.recording
                    loops: Animation.Infinite
                    NumberAnimation { to: 0.25; duration: 700 }
                    NumberAnimation { to: 1.0; duration: 700 }
                }
            }
        }

        Item { Layout.fillWidth: true }

        // Replay transport, only meaningful in replay mode.
        RowLayout {
            spacing: 6
            visible: StreamController.mode === StreamController.Replay

            ToolButton {
                text: StreamController.replayPaused ? "▶" : "❚❚"
                onClicked: StreamController.replayPlayPause()
            }
            ToolButton {
                text: "⏮"
                onClicked: StreamController.replayRestart()
            }
            ProgressBar {
                Layout.preferredWidth: 120
                from: 0
                to: 1
                value: StreamController.replayProgress
            }
        }

        Label {
            text: StreamController.statusText
            color: StreamController.running ? EmgTheme.ok : EmgTheme.textDim
            elide: Text.ElideRight
            Layout.maximumWidth: 320
        }
    }

    FileDialog {
        id: openDialog
        title: qsTr("Open recorded capture")
        nameFilters: [qsTr("EMG captures (*.emgraw)"), qsTr("All files (*)")]
        onAccepted: StreamController.openReplay(selectedFile)
    }

    FolderDialog {
        id: folderDialog
        title: qsTr("Choose a folder for the recording")
        onAccepted: StreamController.startRecording(selectedFolder, true, true)
    }
}
