import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import EmgViewer

ApplicationWindow {
    id: root

    width: 1280
    height: 800
    minimumWidth: 900
    minimumHeight: 560
    visible: true
    title: qsTr("EMG Viewer — FES_Board")
    color: EmgTheme.background

    Shortcut {
        // Space is the scope convention for freeze/run.
        sequence: "Space"
        enabled: StreamController.running
        onActivated: StreamController.togglePause()
    }

    Connections {
        target: StreamController
        function onErrorMessage(message) {
            errorBar.show(message)
        }
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        ConnectionBar {
            Layout.fillWidth: true
        }

        VitalsBar {
            Layout.fillWidth: true
        }

        // Transient error strip. Errors also land in the console pane, so this
        // is a nudge rather than the record of what happened.
        Rectangle {
            id: errorBar

            Layout.fillWidth: true
            implicitHeight: visible ? 30 : 0
            visible: false
            color: EmgTheme.error

            property alias text: errorLabel.text

            function show(message) {
                errorLabel.text = message
                visible = true
                hideTimer.restart()
            }

            Timer {
                id: hideTimer
                interval: 6000
                onTriggered: errorBar.visible = false
            }

            Label {
                id: errorLabel
                anchors.fill: parent
                anchors.leftMargin: EmgTheme.pad
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
                color: "#1A1A1A"
                font.bold: true
            }

            TapHandler {
                onTapped: errorBar.visible = false
            }
        }

        SplitView {
            Layout.fillWidth: true
            Layout.fillHeight: true
            orientation: Qt.Horizontal

            handle: Rectangle {
                implicitWidth: 4
                color: SplitHandle.pressed ? EmgTheme.accent : EmgTheme.border
            }

            ColumnLayout {
                SplitView.fillWidth: true
                SplitView.minimumWidth: 480
                spacing: 0

                ScopeView {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                }

                ConsolePane {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 180
                    Layout.minimumHeight: 0
                }
            }

            ColumnLayout {
                SplitView.preferredWidth: 320
                SplitView.minimumWidth: 260
                spacing: 0

                ScrollView {
                    id: sidebarScroll

                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    contentWidth: availableWidth
                    clip: true

                    ColumnLayout {
                        // Bound to the ScrollView, not to `parent`: parent here
                        // is the internal content item whose width is driven by
                        // contentWidth, which would close the loop.
                        width: sidebarScroll.availableWidth
                        spacing: 0

                        Repeater {
                            model: StreamController.channels
                            delegate: ChannelStrip {
                                required property int index
                                required property string chName
                                required property color chColor
                                required property bool chVisible
                                required property string chJack
                                required property double chLast
                                required property double chRms
                                required property double chMedianHz
                                required property double chPeakHz
                                required property double chBpm
                                required property double chP2p

                                Layout.fillWidth: true

                                channelIndex: index
                                channelName: chName
                                channelColor: chColor
                                channelVisible: chVisible
                                jackName: chJack
                                lastMicrovolts: chLast
                                rmsMicrovolts: chRms
                                medianHz: chMedianHz
                                peakHz: chPeakHz
                                bpm: chBpm
                                p2p: chP2p
                            }
                        }

                        FilterPanel {
                            Layout.fillWidth: true
                        }

                        StatsPanel {
                            Layout.fillWidth: true
                        }
                    }
                }
            }
        }
    }
}
