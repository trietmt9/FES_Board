import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import EmgViewer

// Signal-conditioning controls.
//
// In the sidebar rather than the toolbar: a RowLayout that runs out of width
// overlaps its children instead of eliding them, and the toolbar had already
// reached that point. These are settings, not per-glance controls.
Rectangle {
    id: panel

    implicitHeight: layout.implicitHeight + 2 * EmgTheme.pad
    color: EmgTheme.panel

    ColumnLayout {
        id: layout

        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: EmgTheme.pad
        spacing: 6

        Label {
            text: qsTr("Signal")
            color: EmgTheme.text
            font.bold: true
        }

        ComboBox {
            // The single most consequential setting here. EMG's 20 Hz high-pass
            // sits on top of the QRS complex: use it on an ECG and you lose the
            // P wave, the ST segment and most of the T wave.
            Layout.fillWidth: true
            model: [qsTr("EMG  20–450 Hz"),
                    qsTr("ECG monitor  0.5–40 Hz"),
                    qsTr("ECG diagnostic  0.05–150 Hz")]
            currentIndex: StreamController.signalMode
            onActivated: StreamController.signalMode = currentIndex
        }

        EmgCheckBox {
            // Display only. The envelope always comes from the filtered chain,
            // so turning this off shows you the raw ADC output without making
            // the envelope meaningless.
            text: qsTr("Show filtered")
            checked: StreamController.filterEnabled
            onToggled: StreamController.filterEnabled = checked
        }

        Label {
            text: StreamController.filterEnabled
                  ? qsTr("band-pass %1–%2 Hz")
                      .arg(StreamController.highpassHz < 1
                           ? StreamController.highpassHz.toFixed(2)
                           : StreamController.highpassHz.toFixed(0))
                      .arg(StreamController.lowpassHz.toFixed(0))
                  : qsTr("showing raw ADC output")
            color: StreamController.filterEnabled ? EmgTheme.textDim : EmgTheme.warn
            font.pixelSize: EmgTheme.monoSize
            Layout.fillWidth: true
            elide: Text.ElideRight
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            color: EmgTheme.border
        }

        EmgCheckBox {
            text: qsTr("Mains notch")
            checked: StreamController.notchEnabled
            onToggled: StreamController.notchEnabled = checked
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Label {
                text: qsTr("mains")
                color: EmgTheme.textDim
                font.pixelSize: EmgTheme.monoSize
            }
            Item { Layout.fillWidth: true }
            ComboBox {
                Layout.preferredWidth: 104
                enabled: StreamController.notchEnabled
                model: [50, 60]
                currentIndex: StreamController.mainsHz === 60 ? 1 : 0
                onActivated: StreamController.mainsHz = currentValue
                displayText: currentText + " Hz"
            }
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Label {
                visible: !StreamController.ecgMode
                // The envelope's response time. 250 ms is the textbook sEMG
                // constant but feels sluggish live; 100 ms still averages ~10
                // cycles of the dominant content.
                text: qsTr("envelope")
                color: EmgTheme.textDim
                font.pixelSize: EmgTheme.monoSize
            }
            Item { Layout.fillWidth: true }
            ComboBox {
                visible: !StreamController.ecgMode
                Layout.preferredWidth: 104
                model: [50, 100, 250, 500]
                currentIndex: {
                    const v = Math.round(StreamController.envelopeMs)
                    const i = model.indexOf(v)
                    return i < 0 ? 1 : i
                }
                onActivated: StreamController.envelopeMs = currentValue
                displayText: currentText + " ms"
            }
        }
    }
}
