import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window
import EmgViewer

Rectangle {
    id: scope

    color: EmgTheme.background

    // Physical calibration. Screen.pixelDensity is pixels per millimetre, so
    // the trace can be drawn at a true mm/s and mm/mV rather than "whatever
    // fits the widget" - which is what makes the grid squares mean a fixed
    // number of seconds and millivolts.
    readonly property real pxPerMm: Screen.pixelDensity > 0 ? Screen.pixelDensity : 4.0

    // Microvolts that map to one lane's half-height at the selected gain.
    // Derived, so it follows a window resize and a channel-count change
    // without any imperative plumbing.
    // Highest frequency the current sweep can actually draw as a waveform.
    //
    // A cycle needs roughly 10 pixels to read as a cycle. Below about 3 it is
    // a solid band - min/max decimation paints the full peak-to-peak in every
    // column - and that is indistinguishable from noise however clean the data
    // is. At the clinical 25 mm/s on a 4 px/mm display this ceiling is 10 Hz,
    // which is right for ECG morphology and hopeless for a 100 Hz test tone.
    readonly property real resolvableHz: pxPerMm * StreamController.sweepMmPerSec / 10.0

    readonly property real calibratedRangeUv: {
        const lanes = Math.max(1, StreamController.channels.count)
        const laneHalf = (plotArea.height / lanes) / 2
        const g = StreamController.gainMmPerMv
        return (laneHalf > 0 && g > 0 && pxPerMm > 0)
             ? (laneHalf / (pxPerMm * g)) * 1000
             : 1000
    }

    readonly property bool frequencyMode:
        StreamController.displayMode === StreamController.Frequency

    // Top of the frequency axis. Surface EMG has essentially nothing above
    // 450 Hz, so 500 keeps the band of interest filling the plot instead of
    // squeezing it into the left edge.
    property real maxFrequencyHz: Math.min(500, StreamController.sampleRate / 2)

    ColumnLayout {
        anchors.fill: parent
        spacing: 0

        // Toolbar
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 40
            color: EmgTheme.panelAlt

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: EmgTheme.pad
                anchors.rightMargin: EmgTheme.pad
                spacing: EmgTheme.pad

                Button {
                    // Freezes the DISPLAY. The board keeps streaming, the rings
                    // keep filling and any recording carries on - only the
                    // rendering stops, so you can read a moment without losing
                    // the link.
                    Layout.preferredWidth: 100
                    text: StreamController.paused ? qsTr("▶  Play") : qsTr("❚❚ Pause")
                    enabled: StreamController.running
                    onClicked: StreamController.togglePause()
                }

                ToolSeparator {}

                // Domain toggle
                TabBar {
                    id: domainTabs

                    Layout.preferredWidth: 200
                    Layout.preferredHeight: 30
                    currentIndex: scope.frequencyMode ? 1 : 0

                    onCurrentIndexChanged: {
                        StreamController.displayMode = currentIndex === 1
                            ? StreamController.Frequency
                            : StreamController.Time
                    }

                    TabButton { text: qsTr("Time") }
                    TabButton { text: qsTr("Frequency") }
                }

                ToolSeparator {}

                // ---- Time domain: calibrated sweep speed and gain --------
                //
                // These replace an abstract "window in seconds" slider. A
                // window scaled to whatever the widget happens to be wide can
                // put ten seconds in a hand's width, where beats cannot be
                // separated by eye - which is exactly the "too fast to read"
                // failure. Sweep speed is fixed in mm/s against the display's
                // real pixel density instead, so the trace is the same size it
                // would be on paper regardless of window size or monitor.
                Label {
                    visible: !scope.frequencyMode
                    text: qsTr("Sweep")
                    color: EmgTheme.textDim
                }

                ComboBox {
                    id: sweepBox
                    visible: !scope.frequencyMode
                    Layout.preferredWidth: 132
                    Layout.preferredHeight: 30
                    // The clinical speeds (12.5-50) are for ECG morphology and
                    // rhythm. The fast ones exist because clinical speeds make
                    // anything above a few Hz unreadable, which is not a
                    // theoretical concern: at 25 mm/s on a ~4 px/mm display a
                    // 100 Hz sine gets ONE pixel per cycle, and min/max
                    // decimation then paints the full peak-to-peak in every
                    // column - a solid band that looks exactly like noise.
                    // Rule of thumb: you need ~10 px/cycle to see a waveform,
                    // so mm/s >= f_Hz * 10 / pxPerMm.
                    model: ["12.5 mm/s", "25 mm/s", "50 mm/s",
                            "100 mm/s", "250 mm/s", "500 mm/s"]
                    property var speeds: [12.5, 25, 50, 100, 250, 500]
                    currentIndex: 1
                    onActivated: StreamController.sweepMmPerSec = speeds[currentIndex]
                }

                // Beside the sweep control on purpose. This is the limit the
                // sweep imposes, it is always relevant, and the failure it
                // describes is silent - so it must not be somewhere a narrow
                // window can push it off the toolbar.
                Label {
                    visible: !scope.frequencyMode
                    text: qsTr("≤ %1 Hz").arg(scope.resolvableHz.toFixed(0))
                    color: scope.resolvableHz < 15 ? EmgTheme.warn : EmgTheme.textDim
                    font.pixelSize: 12
                    Layout.preferredWidth: 56
                }

                Label {
                    visible: !scope.frequencyMode && scaleBox.isCalibrated
                    text: qsTr("Gain")
                    color: EmgTheme.textDim
                }

                ComboBox {
                    id: gainBox
                    visible: !scope.frequencyMode && scaleBox.isCalibrated
                    Layout.preferredWidth: 108
                    Layout.preferredHeight: 30
                    // 5-20 mm/mV are the clinical ECG settings. EMG needs an
                    // order of magnitude more: surface EMG is 50 uV to 5 mV, so
                    // at 20 mm/mV a resting trace is 4 px tall and effectively
                    // invisible. The upper values are for that.
                    model: ["5 mm/mV",   "10 mm/mV",  "20 mm/mV",
                            "50 mm/mV",  "100 mm/mV", "200 mm/mV", "500 mm/mV"]
                    property var gains: [5, 10, 20, 50, 100, 200, 500]
                    currentIndex: 1

                    // Follow the signal preset: a gain chosen for ECG is
                    // useless for EMG and vice versa, and having to remember to
                    // change both is how a trace ends up looking flat.
                    function applyForSignal() {
                        currentIndex = StreamController.ecgMode ? 1 : 4  // 10 or 100 mm/mV
                        StreamController.gainMmPerMv = gains[currentIndex]
                    }

                    // Also at startup, not only on change: signalMode is
                    // restored from settings while the gain is not, so an EMG
                    // session would otherwise open at the ECG gain with nothing
                    // to trigger a correction.
                    Component.onCompleted: applyForSignal()

                    Connections {
                        target: StreamController
                        function onSignalModeChanged() { gainBox.applyForSignal() }
                    }
                    onActivated: StreamController.gainMmPerMv = gains[currentIndex]
                }

                // ---- Frequency domain keeps a free span --------------------
                Label {
                    visible: scope.frequencyMode
                    text: qsTr("Analyse")
                    color: EmgTheme.textDim
                }

                Slider {
                    id: windowSlider
                    visible: scope.frequencyMode
                    Layout.preferredWidth: 130
                    from: 0.05
                    to: 10
                    stepSize: 0.05
                    value: StreamController.windowSeconds
                    onMoved: StreamController.windowSeconds = value
                }

                Label {
                    visible: scope.frequencyMode
                    // The analysis span is floored at 1 s, so report what is
                    // actually being transformed, not what the slider reads.
                    text: {
                        const v = Math.max(1, windowSlider.value)
                        return v.toFixed(1) + " s"
                    }
                    color: EmgTheme.text
                    Layout.preferredWidth: 48
                }

                ToolSeparator {}

                Label {
                    text: qsTr("Scale")
                    color: EmgTheme.textDim
                }

                ComboBox {
                    id: scaleBox
                    Layout.preferredWidth: 116
                    Layout.preferredHeight: 30

                    // Auto        per-channel, refits every repaint
                    // Calibrated  mm/mV against the grid - measurable, fixed
                    // Manual      an explicit microvolt range you pick
                    //
                    // Auto and a stated mm/mV are contradictory claims: a trace
                    // that silently rescales cannot be measured against the
                    // grid. Manual sits between them - fixed, but yours.
                    model: [qsTr("Auto"), qsTr("Calibrated"), qsTr("Manual")]

                    // Auto by default. Calibrated is the better view for
                    // MEASURING - it is fixed, so the grid means something -
                    // but fixed also means it clips whatever exceeds the lane,
                    // and a real trace with any residual baseline offset does.
                    // A clipped trace tells you nothing at all; an unmeasurable
                    // one at least shows the morphology. Switch to Calibrated
                    // once the baseline is settled.
                    currentIndex: 0

                    readonly property bool isAuto: currentIndex === 0
                    readonly property bool isCalibrated: currentIndex === 1
                    readonly property bool isManual: currentIndex === 2
                }

                EmgCheckBox {
                    id: rawBox
                    // Ground truth: the samples the MCU sent, one vertex each.
                    // No DC removal, no band-limited reconstruction, no min/max
                    // envelope. Auto scale still applies - that is zoom, not a
                    // change to the waveform.
                    text: qsTr("Raw")
                    checked: false
                    visible: !scope.frequencyMode
                }

                EmgCheckBox {
                    id: removeDcBox
                    // The last piece of processing that used to apply even with
                    // the band-pass off. Unticking it draws absolute
                    // microvolts, offset included - which is how you tell a
                    // railed or open input from a quiet one.
                    text: qsTr("Remove DC")
                    checked: true
                    // Raw overrides it; showing it enabled would imply the tick
                    // still means something.
                    enabled: !rawBox.checked
                    visible: !scope.frequencyMode
                }

                EmgCheckBox {
                    id: smoothBox
                    // Band-limited reconstruction. Only has an effect when
                    // zoomed in past ~1 sample per pixel column; wider windows
                    // use min/max decimation, where interpolating would alias.
                    text: qsTr("Smooth")
                    checked: true
                    enabled: !rawBox.checked
                    visible: !scope.frequencyMode
                }

                Label {
                    text: qsTr("Range")
                    color: EmgTheme.textDim
                    visible: !scope.frequencyMode && scaleBox.isManual
                }

                ComboBox {
                    id: rangeBox
                    visible: !scope.frequencyMode && scaleBox.isManual
                    Layout.preferredWidth: 108
                    Layout.preferredHeight: 30

                    // 1-2-5 sequence, the same progression a scope's V/div uses:
                    // every step is roughly half or double the last, so the
                    // trace changes size predictably.
                    property var uv: [50, 100, 200, 500, 1000, 2000, 5000,
                                      10000, 20000, 50000, 100000, 200000, 400000]
                    model: [ "\u00b150 \u00b5V",  "\u00b1100 \u00b5V", "\u00b1200 \u00b5V",
                             "\u00b1500 \u00b5V", "\u00b11 mV",   "\u00b12 mV",   "\u00b15 mV",
                             "\u00b110 mV",  "\u00b120 mV",  "\u00b150 mV",
                             "\u00b1100 mV", "\u00b1200 mV", "\u00b1400 mV" ]
                    currentIndex: 4          // +/- 1 mV
                }

                Label {
                    visible: scope.frequencyMode
                    Layout.minimumWidth: 0
                    elide: Text.ElideRight
                    text: qsTr("0–%1 Hz · unfiltered").arg(Math.round(scope.maxFrequencyHz))
                    color: EmgTheme.textDim
                    font.pixelSize: EmgTheme.monoSize
                }

                Label {
                    // The ADC's own sinc^3 decimation filter is -3 dB at
                    // 0.262*fDR. Below ~1720 SPS that lands inside the sEMG
                    // band and no amount of host filtering can recover it.
                    visible: StreamController.adcFilterLimitsBand && StreamController.haveInfo
                    Layout.minimumWidth: 0
                    elide: Text.ElideRight
                    text: qsTr("⚠ ADC filter −3 dB at %1 Hz")
                          .arg(StreamController.adcBandwidthHz.toFixed(0))
                    color: EmgTheme.warn
                    font.pixelSize: EmgTheme.monoSize
                }

                Label {
                    visible: !scope.frequencyMode && !scaleBox.isAuto
                             && StreamController.channels.count > 0
                    text: qsTr("fixed \u00b1%1 mV").arg(
                              (scope.calibratedRangeUv / 1000).toFixed(2))
                    color: EmgTheme.textDim
                    font.pixelSize: 12
                }

                Item { Layout.fillWidth: true }
            }
        }

        Item {
            id: plotArea

            Layout.fillWidth: true
            Layout.fillHeight: true

            // Sweep speed drives the window, not the other way round: the
            // window is however many seconds fit on screen at the selected
            // mm/s. Declarative so it re-derives on resize.
            Binding {
                target: StreamController
                property: "windowSeconds"
                when: !scope.frequencyMode && plotArea.width > 0
                value: Math.max(0.05,
                                (plotArea.width / scope.pxPerMm)
                                / StreamController.sweepMmPerSec)
            }

            EcgGrid {
                anchors.fill: parent
                visible: !scope.frequencyMode
                pxPerMm: scope.pxPerMm
                lanes: StreamController.channels.count
            }

            Canvas {
                id: grid
                anchors.fill: parent
                visible: scope.frequencyMode

                property int lanes: StreamController.channels.count
                property bool freq: scope.frequencyMode
                property real maxHz: scope.maxFrequencyHz

                onLanesChanged: requestPaint()
                onFreqChanged: requestPaint()
                onMaxHzChanged: requestPaint()
                onWidthChanged: requestPaint()
                onHeightChanged: requestPaint()

                onPaint: {
                    const ctx = getContext("2d")
                    ctx.reset()
                    ctx.lineWidth = 1

                    const n = Math.max(1, lanes)

                    // Lane separators
                    ctx.strokeStyle = EmgTheme.grid
                    for (let i = 0; i <= n; ++i) {
                        const y = Math.round(i * height / n) + 0.5
                        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke()
                    }

                    if (!freq) {
                        // One vertical division per second of the window.
                        const secs = Math.max(1, Math.round(StreamController.windowSeconds))
                        for (let s = 1; s < secs; ++s) {
                            const x = Math.round(s * width / secs) + 0.5
                            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke()
                        }
                        return
                    }

                    // Frequency axis: a division every 50 Hz, labelled every 100.
                    ctx.font = "10px monospace"
                    for (let f = 50; f < maxHz; f += 50) {
                        const x = Math.round(f * width / maxHz) + 0.5
                        ctx.strokeStyle = EmgTheme.grid
                        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke()
                        if (f % 100 === 0) {
                            ctx.fillStyle = EmgTheme.textDim
                            ctx.fillText(f + " Hz", x + 3, height - 4)
                        }
                    }

                    // Mains. This is the single most useful marker on an EMG
                    // spectrum: a spike here means the electrodes or the ground
                    // are picking up the room, not the muscle.
                    ctx.setLineDash([3, 3])
                    ctx.strokeStyle = EmgTheme.error
                    for (const mains of [50, 60]) {
                        if (mains >= maxHz) continue
                        const x = Math.round(mains * width / maxHz) + 0.5
                        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke()
                    }

                    // Edges of the surface-EMG band (SENIAM), over which the
                    // median frequency is computed.
                    ctx.strokeStyle = EmgTheme.ok
                    for (const edge of [20, 450]) {
                        if (edge >= maxHz) continue
                        const x = Math.round(edge * width / maxHz) + 0.5
                        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke()
                    }
                    ctx.setLineDash([])
                }

                Connections {
                    target: StreamController
                    function onWindowSecondsChanged() { grid.requestPaint() }
                    function onStreamInfoChanged() { grid.requestPaint() }
                }
            }

            WaveformItem {
                id: waveform
                anchors.fill: parent
                visible: !scope.frequencyMode

                controller: StreamController
                // Stays running while frozen: the item throttles its own
                // repaint rate instead, so the frozen frame survives a resize
                // or re-expose. See the timer in WaveformItem.cpp.
                running: StreamController.running && visible
                autoScale: scaleBox.isAuto
                // Calibrated unless the range box is being used explicitly.
                // Ignored while autoScale is on; WaveformItem refits instead.
                rangeMicrovolts: scaleBox.isManual ? rangeBox.uv[rangeBox.currentIndex]
                                                   : scope.calibratedRangeUv
                interpolate: smoothBox.checked
                removeDc: removeDcBox.checked
                raw: rawBox.checked
                gridColor: EmgTheme.grid
            }

            SpectrumItem {
                id: spectrum
                anchors.fill: parent
                visible: scope.frequencyMode

                controller: StreamController
                running: StreamController.running && visible
                autoScale: scaleBox.isAuto
                maxFrequencyHz: scope.maxFrequencyHz
            }

            // Unmistakable: a frozen trace and a dead board look identical
            // otherwise, and confusing the two costs real debugging time.
            Rectangle {
                visible: StreamController.paused
                anchors.top: parent.top
                anchors.right: parent.right
                anchors.margins: 10
                width: pausedLabel.implicitWidth + 18
                height: pausedLabel.implicitHeight + 10
                radius: 3
                color: EmgTheme.warn

                Label {
                    id: pausedLabel
                    anchors.centerIn: parent
                    text: qsTr("PAUSED — display only, still receiving")
                    color: "#14171C"
                    font.bold: true
                    font.pixelSize: EmgTheme.monoSize
                }
            }

            Label {
                anchors.centerIn: parent
                visible: !StreamController.running
                text: qsTr("Connect to the board, or open a recorded capture.")
                color: EmgTheme.textDim
            }
        }
    }
}
